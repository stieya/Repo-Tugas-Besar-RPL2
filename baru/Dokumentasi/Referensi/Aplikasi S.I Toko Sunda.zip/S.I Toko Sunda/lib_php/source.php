<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
<!--[if gt IE 8]>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<![endif]-->
<title>S.I Penjualan Toko Sunda</title>
<link rel="icon" type="image/ico" href="favicon.ico"/>

<link href="css/stylesheets.css" rel="stylesheet" type="text/css" />

<!--[if lte IE 7]>
<script type='text/javascript' src='js/other/lte-ie7.js'></script>
<![endif]-->

<script type='text/javascript' src='js/jquery/jquery-2.0.0.min.js'></script>
<script type='text/javascript' src='js/jquery/jquery-ui-1.10.3.custom.min.js'></script>
<script type='text/javascript' src='js/jquery/jquery-migrate-1.1.1.min.js'></script>
<script type='text/javascript' src='js/jquery/globalize.js'></script>

<script type='text/javascript' src='js/bootstrap/bootstrap.min.js'></script>
<script type='text/javascript' src='js/cookies/jquery.cookies.2.2.0.min.js'></script>

<script type='text/javascript' src='js/mcustomscrollbar/jquery.mCustomScrollbar.concat.min.js'></script>
<script type='text/javascript' src='js/charts/excanvas.min.js'></script>
<script type='text/javascript' src='js/charts/jquery.flot.js'></script>
<script type='text/javascript' src='js/charts/jquery.flot.stack.js'></script>
<script type='text/javascript' src='js/charts/jquery.flot.pie.js'></script>
<script type='text/javascript' src='js/charts/jquery.flot.resize.js'></script>

<script type='text/javascript' src='js/sparklines/jquery.sparkline.min.js'></script>

<script type='text/javascript' src='js/datatables/jquery.dataTables.min.js'></script>

<script type='text/javascript' src='js/scrollup/jquery.scrollUp.min.js'></script>
<script type='text/javascript' src='js/select2/select2.min.js'></script>
<script type='text/javascript' src='js/uniform/jquery.uniform.min.js'></script>
<script type='text/javascript' src='js/tagsinput/jquery.tagsinput.min.js'></script>
<script type='text/javascript' src='js/multiselect/jquery.multi-select.js'></script>
<script type='text/javascript' src='js/ibutton/jquery.ibutton.min.js'></script>
<script type='text/javascript' src='js/colorpicker/colorpicker.js'></script>
<script type='text/javascript' src='js/timepicker/jquery-ui-timepicker-addon.js'></script>

<script type='text/javascript' src='js/plugins.js'></script>
<script type='text/javascript' src='js/actions.js'></script>
<script type='text/javascript' src='js/charts.js'></script>

<script type='text/javascript' src='lib_js/pengaturan.js'></script>
<script type='text/javascript' src='lib_js/pengguna.js'></script>
<script type='text/javascript' src='lib_js/distributor.js'></script>
<script type='text/javascript' src='lib_js/transaksi_suplai.js'></script>
<script type='text/javascript' src='lib_js/transaksi_jual.js'></script>
<script type='text/javascript' src='lib_js/barang.js'></script>