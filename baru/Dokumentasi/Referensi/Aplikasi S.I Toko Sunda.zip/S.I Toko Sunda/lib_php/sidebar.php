<?php
$modul = "dashboard";
$submodul = "dashboard";
if(isset($_GET['modul'])){
    $modul = $_GET['modul'];
}
if(isset($_GET['submodul'])){
    $submodul = $_GET['submodul'];
}
?>
<div id="sidebar">

    <div class="user">
        <div class="pic">
            <img src="img/examples/users/user.png"/>
        </div>
        <div class="info">
            <div class="name">
                <a href="#">Admin</a>
            </div>
        </div>
    </div>

    <ul class="navigation">
        <li class="<?php if($modul=="dashboard") echo "active"?>">
            <a href="index.php"><img src="img/icons/computer-imac.png"> Dashboard</a>
        </li>
        <li class="openable <?php if($modul=="barang") echo "active open"?>">
            <a href="#"><img src="img/icons/bag.png"> Barang</a>
            <ul>
                <li><a href="?modul=barang&submodul=tambah_barang">Tambah Barang</a></li>
                <li><a href="?modul=barang&submodul=tampil_barang">Tampil Barang</a></li>
                <li><a href="?modul=barang&submodul=tambah_barang_rusak">Tambah Barang Rusak</a></li>
                <li><a href="?modul=barang&submodul=daftar_barang_rusak">Tampil Barang Rusak</a></li>
                <li><a href="?modul=barang&submodul=tambah_jenis_barang">Tambah Jenis Barang</a></li>
                <li><a href="?modul=barang&submodul=tampil_jenis_barang">Tampil Jenis Barang</a></li>
            </ul>
        </li>
        <li class="openable <?php if($modul=="transaksi_suplai") echo "active open"?>">
            <a href="#"><img src="img/icons/bended-arrow-down.png"> Transaksi Suplai</a>
            <ul>
                <li><a href="?modul=transaksi_suplai&submodul=tambah_transaksi">Tambah Transaksi</a></li>
                <li><a href="?modul=transaksi_suplai&submodul=tampil_transaksi">Tampil Transaksi</a></li>
            </ul>
        </li>
        <li class="openable <?php if($modul=="transaksi_penjualan") echo "active open"?>">
            <a href="#"><img src="img/icons/shopping-cart-2.png"> Transaksi Penjualan</a>
            <ul>
                <li><a href="?modul=transaksi_penjualan&submodul=tambah_transaksi">Tambah Transaksi</a></li>
                <li><a href="?modul=transaksi_penjualan&submodul=tampil_transaksi">Tampil Transaksi</a></li>
            </ul>
        </li>
        <li class="openable <?php if($modul=="distributor") echo "active open"?>">
            <a href="#"><img src="img/icons/truck.png"> Distributor</a>
            <ul>
                <li><a href="?modul=distributor&submodul=tambah_distributor">Tambah Distributor</a></li>
                <li><a href="?modul=distributor&submodul=tampil_distributor">Tampil Distributor</a></li>
            </ul>
        </li>
        <?php
        if($_SESSION['hak_akses'] == "super"){
        ?>
        <li class="openable <?php if($modul=="pengguna") echo "active open"?>">
            <a href="#"><img src="img/icons/user.png"> Pengguna</a>
            <ul>
                <li><a href="?modul=pengguna&submodul=tambah_pengguna">Tambah Pengguna</a></li>
                <li><a href="?modul=pengguna&submodul=tampil_pengguna">Tampil Pengguna</a></li>
            </ul>
        </li>
        <?php
        }
        ?>
    </ul>

</div>