function hapusPengguna(id,nama,isdel){
    if(confirm("Apakah Pengguna Dengan Nama \""+nama.replace('_',' ')+"\" Akan Dihapus?"))
        document.location.href="modul/pengguna/action_pengguna.php?action=hapus_user&id_user="+id;
}

function cariPengguna(){
    cari = $("#cari_pengguna").val();
    $.post("modul/pengguna/cari_pengguna.php",{"cari" : cari}).done(function(data){
        $("#tb-daftar-pengguna").html(data);
        $("#DataTables_Table_0_paginate").html("");
    });
}

idUser = "";
namaUser = "";
password = "";
function cekIdPengguna(){
    idUser = $("#id_user").val();
    if(idUser != ""){
        $.post("modul/pengguna/getID.php",{"id" : idUser})
            .done(function(data){
                if(data == "ada"){
                    $("#warning1").html(" <img src=img/icons/cross-script.png>");
                } else {
                    $("#warning1").html(" <img src=img/icons/success.png>");
                }
            });
    } else {
        $("#warning1").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekNamaPengguna(){
    namaUser = $("#nama_user").val();
    if(namaUser != ""){
        $("#warning2").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning2").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekPasswordPengguna(){
    password = $("#password").val();
    if(password != "" && password.length >= 5){
        $("#warning3").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning3").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekValidPengguna(){
    if(idUser != "" && namaUser != "" && password != ""){
        return true;
    } else {
        alert('Mohon lengkapi data!');
        return false;
    }
}