/**
 * Created by Akhinahasan on 06/12/13.
 */
ArrNamaBarang = [];
var suplai = [];
id=0;
idItem = 0;
setTimeout(function(){$('#penampung').hide()},100);

function hapusTransaksiSuplai(no_suplai,isdel){
    if(confirm("Apakah Transaksi dengan no suplai:\" "+ no_suplai.replace('_',' ')+" \" Akan Dihapus?"))
        document.location.href="modul/transaksi_suplai/action_transaksi_suplai.php?action=hapus_trasaksiSuplai&no_suplai="+no_suplai;
}
function hapusDetailTransaksiSuplai(id_detail_tr,no_suplai,isdel){
    if(confirm("Apakah Detail Transaksi dengan no suplai: \""+no_suplai.replace('_',' ')+"\" akan dihapus?"))
        document.location.href="modul/transaksi_suplai/action_transaksi_suplai.php?action=hapus_detail_trasaksiSuplai&no_suplai="+no_suplai +"&id_detail_tr="+id_detail_tr;

}
function tambahDetailSuplai(){
    kode_barang=$('#kode_barang').val();
    harga_suplai=$('#harga_suplai').val();
    jumlah=$('#jumlah').val();
    $('#harga_suplai').val("");
    $('#jumlah').val("");
    suplai[id]=kode_barang;
    id++;
    suplai[id]=harga_suplai;
    id++;
    suplai[id]=jumlah;
    id++;
    isi='<tr><td>'+ArrNamaBarang[kode_barang]+'</td><td>'+jumlah+'</td><td>'+harga_suplai+'</td><td><a style="cursor: pointer" onclick=hapusItemSuplai("'+(idItem)+'")><img src="img/icons/cross-script.png">Hapus</a></td></tr>';
    idItem++;
    $('#tdetail_suplai').append(isi);
    $('#array_detail').val(suplai);

    $('#penampung').show()
}


function message(){

}

function hapusItemSuplai(idItem){
    var suplaiBaru = [];
    id_ = idItem*3;
    for(i=id_;i<id-3;i++){
        suplai[i] = suplai[i+3];
    }
    id-=3;
    idItem--;
    for(i=0;i<id;i++){
        suplaiBaru[i] = suplai[i];
    }
    suplai = suplaiBaru;

    isi = "";
    j = 0;
    for(i=0;i<id;i+=3){
        isi += '<tr><td>'+ArrNamaBarang[suplai[i]]+'</td><td>'+suplai[i+2]+'</td><td>'+suplai[i+1]+'</td><td><a style="cursor: pointer" onclick=hapusItemSuplai("'+(j)+'")><img src="img/icons/cross-script.png">Hapus</a></td></tr>';
        j++;
    }
    $('#tdetail_suplai').html(isi);
    $('#array_detail').val(suplai);
}
