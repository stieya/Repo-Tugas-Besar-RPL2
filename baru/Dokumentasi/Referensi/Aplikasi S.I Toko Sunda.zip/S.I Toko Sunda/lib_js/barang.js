function hapusBarang(id,nama,isdel){
    if(confirm("Apakah Barang \""+nama.replace('_',' ')+"\" Akan Dihapus?"))
        document.location.href="modul/barang/action_barang.php?action=hapus_barang&id_barang="+id;
}

function hapusBarangRusak(id,nama,isdel){
    if(confirm("Apakah Barang Rusak \""+nama.replace('_',' ')+"\" Akan Dihapus?"))
        document.location.href="modul/barang/action_barang_rusak.php?action=hapus_barang&id_barang="+id;
}

function hapusJenisBarang(id,nama,isdel){
    if(confirm("Apakah Jenis Barang \""+nama.replace('_',' ')+"\" Akan Dihapus?"))
        document.location.href="modul/barang/action_barang.php?action=hapus_jenis_barang&id="+id;
}

kodeBarang = "";
namaBarang = "";
satuan = "";
jumlah = "";
harga = "";
jumlah_rusak = "";

function cekKodeBarang(){
    kodeBarang = $("#id_barang").val();
    // && !isNaN(kodeBarang.substr(2,3)) && isNaN(kodeBarang.substr(0,2))
    if(kodeBarang.length == 5){
        $.post("modul/barang/getKode.php",{"kode" : kodeBarang})
        .done(function(data){
            if(data == "ada"){
                $("#warning1").html(" <img src=img/icons/cross-script.png>");
            } else {
                $("#warning1").html(" <img src=img/icons/success.png>");
            }
        });
    } else {
        $("#warning1").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekNamaBarang(){
    namaBarang = $("#nama_barang").val();
    if(namaBarang != ""){
        $("#warning2").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning2").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekJenisBarang(){
    jenisBarang = $("#jenis_barang").val();
    if(jenisBarang != ""){
        $("#warning3").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning3").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekSatuanBarang(){
    satuan = $("#satuan").val();
    if(satuan != ""){
        $("#warning4").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning4").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekJumlahBarang(){
    jumlah = $("#jumlah").val();
    if(!isNaN(jumlah) && jumlah != '' && jumlah >= 0 && Math.ceil(jumlah) == jumlah){
        $("#warning5").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning5").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekHargaBarang(){
    harga = $("#harga_jual").val();
    if(!isNaN(harga) && harga != "" && harga >= 0 && Math.ceil(harga) == harga){
        $("#warning6").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning6").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekValidBarang(){
    //&& !isNaN(kodeBarang.substr(2,3)) && isNaN(kodeBarang.substr(0,2))
    if(kodeBarang.length == 5 
        && namaBarang != "" && satuan != "" && jumlah != "" && !isNaN(jumlah) && jumlah >= 0 && !isNaN(harga) && harga != "" && harga >= 0 && Math.ceil(jumlah) == jumlah && Math.ceil(harga) == harga){
        return true;
    } else {
        alert('Mohon lengkapi data dengan benar!');
        return false;
    }
}

function cekJumlahBarangRusak(){
    jumlah_rusak = $("#jumlah_rusak").val();
    if(!isNaN(jumlah_rusak) && jumlah_rusak != '' && jumlah_rusak > 0 && Math.ceil(jumlah_rusak) == jumlah_rusak){
        $("#warning2").html(" <img src=img/icons/success.png>");
    } else {
        $("#warning2").html(" <img src=img/icons/cross-script.png>");
    }
}

function cekValidBarangRusak(){
    //&& !isNaN(kodeBarang.substr(2,3)) && isNaN(kodeBarang.substr(0,2))
    if(!isNaN(jumlah_rusak) && jumlah_rusak != '' && jumlah_rusak > 0 && Math.ceil(jumlah_rusak) == jumlah_rusak){
        return true;
    } else {
        alert('Mohon lengkapi data dengan benar!');
        return false;
    }
}