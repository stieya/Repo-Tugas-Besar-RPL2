<?php

include("../../lib_php/connection.php");

$id = "";
if(isset($_POST['id'])){
	$id = $_POST['id'];
}

$query = mysql_query("SELECT * FROM user WHERE id_user = '$id' ");

if(mysql_num_rows($query) > 0){
    echo "ada";
}
?>