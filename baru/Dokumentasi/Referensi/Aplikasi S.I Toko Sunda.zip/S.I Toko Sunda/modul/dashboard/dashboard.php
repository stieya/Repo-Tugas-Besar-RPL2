<div class="head">
    <div class="info">
        <h1>Dashboard</h1>
    </div>

    <div class="search">
    </div>
</div>

<div class="content">

<div class="row-fluid">
    <div class="span6">
        <br>
        <img src="img/logo-big.jpg">
    </div>
    <div class="span6">
        <br>
        <div class="widgets">
            <a class="button text-error" href="#">
                <div class="icon">
                    <span class="mChartBar" sparkWidth="100" sparkHeight="30" sparkType="bar" sparkBarColor="#b84b48">5,6,4,6,5,4,5,6,8,5,6</span>
                </div>
                <div class="info">
                    <span>Sales</span>
                    <p class="muted">Date: 05.06.2013</p>
                    <p>Total: 102</p>
                </div>
            </a>
            <a class="button text-success" href="#">
                <div class="icon">
                    <span class="mChartBar" sparkType="pie" sparkWidth="30" sparkHeight="30">170,532,75</span>
                </div>
                <div class="info">
                    <span>Visitors</span>
                    <p>New: 170;</p>
                    <p>Returned: 532;</p>
                </div>
            </a>
        </div>
        <div class="block">
            <div class="content closed">
                <ul class="boxes nmt">
                    <?php
                    $jb = mysql_fetch_row(mysql_query("SELECT COUNT(kode_barang) FROM barang"));
                    $ts = mysql_fetch_row(mysql_query("SELECT COUNT(no_suplai) FROM transaksi_suplai"));
                    $tj = mysql_fetch_row(mysql_query("SELECT COUNT(no_transaksi) FROM transaksi_jual"));
                    ?>
                    <li><?php echo $jb[0];?><span>Jumlah Barang</span></li>
                    <li><?php echo $ts[0];?><span>Transaksi Suplai</span></li>
                    <li><?php echo $tj[0];?><span>Transaksi Jual</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>