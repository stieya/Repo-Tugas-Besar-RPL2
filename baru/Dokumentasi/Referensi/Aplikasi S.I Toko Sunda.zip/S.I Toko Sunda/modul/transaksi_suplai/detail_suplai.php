<div class="head">
    <div class="info">
        <h1>Detail Transaksi Suplain</h1>
    </div>

</div>
<div class="content">
    <div class="row-fluid">

        <div class="span12">

            <?php
            $result = "";
            if(isset($_GET['result'])){
                $result = $_GET['result'];
            }

            if($result == 'success_h'){
                ?>
                <div class="alert alert-success">
                    <strong>Berhasil hapus detail Suplai.</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            } else if($result == 'failed_h'){
                ?>
                <div class="alert alert-error">
                    <strong>Gagal hapus detail transaksi suplai!</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            }
            else if($result == 'success_t'){
                ?>
                <div class="alert alert-success">
                    <strong>Berhasil ubah detail transaksi suplai.</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            } else if($result == 'failed_t'){
                ?>
                <div class="alert alert-error">
                    <strong>Gagal ubah detail transaksi suplai!</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            }
            ?>

            <div class="block">
                <div class="head">
                    <h2>Tabel Detail Transaksi Suplai</h2>
                    <ul class="buttons">
                        <li><a href="#" class="block_loading"><span class="i-cycle"></span></a></li>
                        <li><a href="#" class="block_toggle"><span class="i-arrow-down-3"></span></a></li>
                        <li><a href="#" class="block_remove"><span class="i-cancel-2"></span></a></li>
                    </ul>
                </div>
                <div class="content np table-sorting">

                    <table cellpadding="0" cellspacing="0" width="100%" class="simple_sort">
                        <thead>
                        <tr>
                            <th width="7%">ID</th>
                            <th width="7%">No Suplai</th>
                            <th width="15%">Tanggal</th>
                            <th width="15%">Supplyer</th>
                            <th width="15%">Nama Barang</th>
                            <th width="15%">Harga Suplai</th>
                            <th width="15%">Jumlah Suplai</th>
                            <th width="10%">ID User</th>
                            <th width="10%">Aksi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        $no_suplai_am = "";
                        if(isset($_GET['no_suplai'])){
                            $no_suplai_am = $_GET['no_suplai'];
                        }

                        $select = mysql_query("SELECT id,no_suplai,barang.`nama_barang`AS nama_barang,`transaksi_suplai`.`tanggal_suplai` AS tanggal_suplai,pemasok.`nama`AS nama_pemasok,harga_suplai,`jumlah_suplai`,id_user
                                               FROM detail_transaksi_suplai
                                               JOIN barang USING (kode_barang)
                                               JOIN `transaksi_suplai` USING(no_suplai)
                                               JOIN pemasok USING (id_pemasok)
                                               WHERE no_suplai = '$no_suplai_am'");

                        while($data = mysql_fetch_array($select)){
                            echo '<tr>';
                            echo '<td>'.$data['id'].'</td>';
                            echo '<td>'.$data['no_suplai'].'</td>';
                            echo '<td>'.$data['tanggal_suplai'].'</td>';
                            echo '<td>'.$data['nama_pemasok'].'</td>';
                            echo '<td>'.$data['nama_barang'].'</td>';
                            echo '<td>Rp.'.$data['harga_suplai'].'</td>';
                            echo '<td>'.$data['jumlah_suplai'].'</td>';
                            echo '<td>'.$data['id_user'].'</td>';
                            echo '<td>
                                <a style="cursor: pointer" onclick=hapusDetailTransaksiSuplai("'.$data['id'].'","'.$data['no_suplai'].'")><img src="img/icons/cross-script.png">Hapus</a>
                            </td>';
                            echo '</tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                    <div class="footer">
                        <div class="side fr">
                            <a href="index.php?modul=transaksi_suplai&submodul=tampil_transaksi" class="btn btn-primary" type="button" style="padding: 4px 15px 4px 15px">Kembali</a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>