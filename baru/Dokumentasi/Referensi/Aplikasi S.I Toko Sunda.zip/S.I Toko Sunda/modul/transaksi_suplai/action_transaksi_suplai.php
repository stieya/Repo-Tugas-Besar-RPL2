<?php
/**
 * Created by PhpStorm.
 * User: Akhinahasan
 * Date: 06/12/13
 * Time: 22:21
 */
include("../../lib_php/connection.php");

$no_suplai_am = "";
$id_detail_tr_am = "";
$tanggal_am = "";
$id_pemasok_am = "";
$kode_barang_am = "";
$harga_suplai_am = "";
$jumlah_am = "";
$action_am = "";
$link_am = "";
$icon_am = "";
$array_detail="";

$id_admin_am = "admin";

if(isset($_GET['array_detail'])){
    $array_detail=$_GET['array_detail'];
    $array_detail=explode(',',$array_detail);
}

if(isset($_GET['no_suplai'])){
    $no_suplai_am = $_GET['no_suplai'];
}

if(isset($_GET['id_detail_tr'])){
    $id_detail_tr_am = $_GET['id_detail_tr'];
}

if(isset($_GET['tanggal'])){
    $tanggal_am = $_GET['tanggal'];
    $month=substr($tanggal_am,0,2);
    $year=substr($tanggal_am,6,4);
    $day=substr($tanggal_am,3,2);
    $tanggal_am=$year.'-'.$month.'-'.$day;
}

if(isset($_GET['id_pemasok'])){
    $id_pemasok_am = $_GET['id_pemasok'];
}

if(isset($_GET['kode_barang'])){
    $kode_barang_am = $_GET['kode_barang'];

}

if(isset($_GET['harga_suplai'])){
    $harga_suplai_am= $_GET['harga_suplai'];
}

if(isset($_GET['jumlah'])){
    $jumlah_am = $_GET['jumlah'];
}

if(isset($_GET['action'])){
    $action_am = $_GET['action'];
}

function simpan_transaksi_suplai($id_pemasok,$id_admin_am,$array_detail){
    $tanggal = date("Y-m-d");
    $insert = mysql_query("INSERT INTO transaksi_suplai VALUES(null,'$tanggal','$id_pemasok','$id_admin_am')");
    $select = mysql_query("SELECT no_suplai FROM transaksi_suplai ORDER BY no_suplai DESC LIMIT 1");

    $temp = mysql_fetch_array($select);
    $i=1;
    $isi='';
    $kode_b = 0;
    foreach ($array_detail as $a) {
        $isi.="'".$a."',";
        if(($i % 3 == 0)){
            $isi = substr($isi,0,strlen($isi)-1);
            $insert=mysql_query("INSERT INTO detail_transaksi_suplai VALUES (null,'$temp[0]',$isi)");
            $isi = "";
            $update = mysql_query("UPDATE barang SET jumlah=jumlah+'$a' WHERE kode_barang = '$kode_b'");
        }
        if(($i % 3 == 1)){
            $kode_b = $a;
        }

    $i++;

     }

    if($insert){
        header("location:../../index.php?modul=transaksi_suplai&submodul=tambah_transaksi&result=success");
    } else {
        header("location:../../index.php?modul=transaksi_suplai&submodul=tambah_transaksi&result=failed");
    }
}

function hapus_detail_trasaksiSuplai($id_detail_tr,$no_suplai){
    $delete = mysql_query("DELETE FROM detail_transaksi_suplai WHERE id = '$id_detail_tr'");
    if($delete){
        header("location:../../index.php?modul=transaksi_suplai&submodul=detail_suplai&result=success_h&no_suplai=$no_suplai");
    } else {
        header("location:../../index.php?modul=transaksi_suplai&submodul=detail_suplai&result=failed_h&no_suplai=$no_suplai");
    }
}

/*function tambah_detail_suplai($tanggal,$id_pemasok,$kode_barang,$jumlah,$harga){

       $insert = mysql_query("INSERT INTO transaksi_suplai (tanggal_suplai,id_pemasok)VALUES ('$tanggal','$id_pemasok)'");
        $update = mysql_query("UPDATE barang SET jumlah = jumlah - $jumlah where kode_barang = '$kode_barang'");
       if($insert && $update){
            header("location:../../index.php?modul=transaksi_penjualan&submodul=tambah_detail_transaksi&no_transaksi=$no_transaksi");
        } else {
            header("location:../../index.php?modul=transaksi_penjualan&submodul=tambah_detail_transaksi&no_transaksi=$no_transaksi");
        }

}
*/

function hapus_trasaksiSuplai($no_suplai){
    $delete = mysql_query("DELETE FROM transaksi_suplai WHERE no_suplai= '$no_suplai'");
    if($delete){
        header("location:../../index.php?modul=transaksi_suplai&submodul=tampil_transaksi&result=success_h");
    } else {
        header("location:../../index.php?modul=transaksi_suplai&submodul=tampil_transaksi&result=failed_h");
    }
}


if($action_am == "simpan_transaksi"){
    simpan_transaksi_suplai($id_pemasok_am,$id_admin_am,$array_detail);
} else if($action_am == "hapus_trasaksiSuplai"){
    hapus_trasaksiSuplai($no_suplai_am);
} else if($action_am == "hapus_detail_trasaksiSuplai"){
    hapus_detail_trasaksiSuplai($id_detail_tr_am,$no_suplai_am);

}
?>
