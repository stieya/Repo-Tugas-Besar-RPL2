<script language="javascript">
<?php
    $query = mysql_query("SELECT kode_barang, nama_barang FROM barang");
    while($data = mysql_fetch_array($query)){
        echo 'ArrNamaBarang["'.$data[0].'"] = "'.$data[1].'";';
    }
?>
</script>
<div class="head">
    <div class="info">
        <h1>Tambah Transaksi</h1>
    </div>

    <div class="search">
        <form action="#" method="post">
            <input type="text" placeholder="search..."/>
            <button type="submit"><span class="i-calendar"></span></button>
            <button type="submit"><span class="i-magnifier"></span></button>
        </form>
    </div>
</div>
<div class="content">
    <div class="row-fluid">
        <!-- Code Here -->
        <div class="span8">
            <?php
            $result = "";
            if(isset($_GET['result'])){
                $result = $_GET['result'];
            }

            if($result == 'success'){
                ?>
                <div class="alert alert-success">
                    <strong>Berhasil tambah transaksi suplai </strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            } else if($result == 'failed'){
                ?>
                <div class="alert alert-error">
                    <strong>Gagal tambah transaksi suplai !</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            } else if($result == 'failed_j'){
                ?>
                <div class="alert alert-error">
                    <strong>Barang tidak cukup !</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            }
            ?>

            <form action="modul/transaksi_suplai/action_transaksi_suplai.php" method="get" enctype="multipart/form-data">
                <div class="block">
                    <div class="head">
                        <h2>Form Tambah Transaksi Suplai</h2>
                    </div>
                    <div class="content np">
                        <input type="hidden" name="action" value="tambah_transaksi_suplai">
                        <!--
                        <div class="controls-row">
                            <div class="span3">Tanggal:</div>
                            <div class="span9">
                                <div class="input-prepend">
                                    <span class="add-on"><i class="i-calendar"></i></span>
                                    <input type="text" name="tanggal" class="datepicker"/>
                                </div>
                            </div>
                        </div>
                        -->
                        <div class="controls-row">
                            <div class="span3">Nama Suplier</div>
                            <div class="span9">
                                <select class="select2" style="width: 220px;" name="id_pemasok">
                                    <?php
                                    $query = mysql_query("SELECT id_pemasok,nama FROM pemasok");
                                    while($data = mysql_fetch_array($query)){
                                        echo '<option value="'.$data['id_pemasok'].'">'.$data['nama'].'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="controls-row">
                            <div class="span3">Nama Barang</div>
                            <div class="span9">
                                <select class="select2" style="width: 220px;" name="kode_barang" id="kode_barang">
                                    <?php
                                    $query = mysql_query("SELECT kode_barang,nama_barang FROM barang");
                                    while($data = mysql_fetch_array($query)){
                                        echo '<option value="'.$data['kode_barang'].'">'.$data['nama_barang'].'</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="controls-row">
                            <div class="span3">Jumlah Barang</div>
                            <div class="span9"><input type="text" name="jumlah" id='jumlah' placeholder="Jumlah Beli"/></div>
                        </div>
                        <div class="controls-row">
                            <div class="span3">Harga Barang</div>
                            <div class="span9"><input type="text" name="harga" id="harga_suplai" placeholder="Harga Barang"/></div>
                        </div>
                    </div>
                    <div class="footer">
                        <div class="side fr">
                            <input onclick="tambahDetailSuplai()" type="button" class="btn btn-primary" value="Tambah">
                        </div>
                    </div>
                </div>
                <div class="block" id="penampung">
                    <div class="head">
                        <h2>Daftar Transaksi Suplai</h2>
                        <ul class="buttons">
                            <li><a href="#" class="block_loading"><span class="i-cycle"></span></a></li>
                            <li><a href="#" class="block_toggle"><span class="i-arrow-down-3"></span></a></li>
                            <li><a href="#" class="block_remove"><span class="i-cancel-2"></span></a></li>
                        </ul>
                    </div>
                    <input type="hidden" name="action" value="simpan_transaksi">
                    <input type="hidden" name="array_detail" value="" id="array_detail">
                    <div class="content np">
                        <table cellpadding="0" cellspacing="0" width="100%">
                            <thead>
                            <tr>
                                <th width="15%">Nama Barang</th>
                                <th width="10%">Jumlah suplai</th>
                                <th width="10%">Harga Suplai</th>
                                <th width="10%">Aksi</th>
                            </tr>
                            </thead>
                            <tbody id="tdetail_suplai">
                            </tbody>
                        </table>
                        <div class="footer">
                            <div class="side fr">
                                <input type="submit" class="btn btn-primary" value="Simpan">
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>