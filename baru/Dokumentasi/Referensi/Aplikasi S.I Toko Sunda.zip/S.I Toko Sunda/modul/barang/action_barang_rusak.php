<?php
include("../../lib_php/connection.php");

$nama_barang_am = "";
$id_barang_am = "";
$satuan_am = "";
$jumlah_am = "";
$jumlah_rusak_am = "";
$harga_jual_am = "";
$action_am = "";
$link_am = "";
$icon_am = "";
$id_admin_am = "admin";

if(isset($_GET['nama_barang'])){
   $nama_barang_am = $_GET['nama_barang'];
}

if(isset($_GET['id_barang'])){
    $id_barang_am = $_GET['id_barang'];
}

if(isset($_GET['satuan'])){
    $satuan_am = $_GET['satuan'];
}

if(isset($_GET['harga_jual'])){
   $harga_jual_am = $_GET['harga_jual'];
}

if(isset($_GET['action'])){
    $action_am = $_GET['action'];
}

if(isset($_GET['jumlah'])){
    $jumlah_am = $_GET['jumlah'];
}

if(isset($_GET['jumlah_rusak'])){
    $jumlah_rusak_am = $_GET['jumlah_rusak'];
}

function simpan_barang($id_barang,$jumlah_rusak){
    $query = mysql_query("SELECT * FROM barang_rusak WHERE kode_barang = '$id_barang'");
    $query2 = mysql_query("SELECT jumlah FROM barang WHERE kode_barang = '$id_barang'");
    $data = mysql_fetch_row($query2);
    if($jumlah_rusak > $data[0]){
        header("location:../../index.php?modul=barang&submodul=tambah_barang_rusak&result=failed_j");
        return;
    } else if($jumlah_rusak == 0){
        header("location:../../index.php?modul=barang&submodul=tambah_barang_rusak&result=failed");
        return;
    }


    if(mysql_num_rows($query) == 0){
        $insert = mysql_query("INSERT INTO barang_rusak VALUES('$id_barang','$jumlah_rusak')");
    } else {
        $insert = mysql_query("UPDATE barang_rusak SET jumlah_rusak=jumlah_rusak+'$jumlah_rusak' WHERE kode_barang = '$id_barang'");
    }

    if($insert){
        $update = mysql_query("UPDATE barang SET jumlah=jumlah-'$jumlah_rusak' WHERE kode_barang = '$id_barang'");
        header("location:../../index.php?modul=barang&submodul=tambah_barang_rusak&result=success");
    } else {
        header("location:../../index.php?modul=barang&submodul=tambah_barang_rusak&result=failed");
    }
}

function ubah_barang($jumlah_rusak,$id_barang){
    $update = false;
    if($jumlah_rusak != "")
        $update = mysql_query("UPDATE barang_rusak SET jumlah_rusak = '$jumlah_rusak' WHERE kode_barang = '$id_barang'");
    if($update){
        header("location:../../index.php?modul=barang&submodul=daftar_barang_rusak&result=success_u");
    } else {
        header("location:../../index.php?modul=barang&submodul=ubah_barang_rusak&id_barang=$id_barang&result=failed");
    }
}

function hapus_barang($id){
    $delete = mysql_query("DELETE FROM barang_rusak WHERE kode_barang = '$id'");
    if($delete){
        header("location:../../index.php?modul=barang&submodul=daftar_barang_rusak&result=success_h");
    } else {
        header("location:../../index.php?modul=barang&submodul=daftar_barang_rusak&result=failed_h");
    }
}

if($action_am == "simpan_barang"){
    simpan_barang($id_barang_am,$jumlah_rusak_am);
} else if($action_am == "ubah_barang"){
    ubah_barang($jumlah_rusak_am, $id_barang_am);
} else if($action_am == "hapus_barang"){
    hapus_barang($id_barang_am);
}
?>