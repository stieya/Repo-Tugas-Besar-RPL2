<?php
include("../../lib_php/connection.php");

$nama_barang_am = "";
$id_barang_am = "";
$satuan_am = "";
$jumlah_am = "";
$jumlah_rusak_am = "";
$harga_jual_am = "";
$action_am = "";
$link_am = "";
$icon_am = "";
$jenis_barang = "";
$id = "";
$kode_jenis = "";
$id_admin_am = "admin";

if(isset($_GET['id'])){
    $id = $_GET['id'];
}

if(isset($_GET['nama_barang'])){
   $nama_barang_am = $_GET['nama_barang'];
}

if(isset($_GET['id_barang'])){
    $id_barang_am = $_GET['id_barang'];
}

if(isset($_GET['satuan'])){
    $satuan_am = $_GET['satuan'];
}

if(isset($_GET['harga_jual'])){
   $harga_jual_am = $_GET['harga_jual'];
}

if(isset($_GET['action'])){
    $action_am = $_GET['action'];
}

if(isset($_GET['jumlah'])){
    $jumlah_am = $_GET['jumlah'];
}

if(isset($_GET['jenis_barang'])){
    $jenis_barang = $_GET['jenis_barang'];
}

if(isset($_GET['kode_jenis'])){
    $kode_jenis = $_GET['kode_jenis'];
}

function simpan_barang($id_barang,$nama_barang,$satuan,$jumlah,$harga_jual,$jenis_barang){
    $insert = mysql_query("INSERT INTO barang VALUES('$id_barang','$nama_barang','$satuan','$jumlah','$harga_jual','$jenis_barang')");

    if($insert){
        header("location:../../index.php?modul=barang&submodul=tambah_barang&result=success");
    } else {
        header("location:../../index.php?modul=barang&submodul=tambah_barang&result=failed");
    }
}

function ubah_barang($nama_barang,$satuan,$jumlah,$harga_jual,$id_barang){
    $update = false;
    if($nama_barang != "")
        $update = mysql_query("UPDATE barang SET nama_barang = '$nama_barang', satuan = '$satuan', jumlah = '$jumlah', harga_jual = '$harga_jual' WHERE kode_barang = '$id_barang'");
    if($update){
        header("location:../../index.php?modul=barang&submodul=tampil_barang&result=success_u");
    } else {
        header("location:../../index.php?modul=barang&submodul=ubah_barang&id_barang=$id_barang&result=failed");
    }
}

function ubah_barang_rusak($jumlah_rusak,$id_barang){
    $update = mysql_query("UPDATE barang_rusak SET jumlah_rusak = '$jumlah_rusak' WHERE kode_barang = '$id_barang'");
    if($update){
        header("location:../../index.php?modul=barang&submodul=tampil_barang_rusak&result=success_u");
    } else {
        header("location:../../index.php?modul=barang&submodul=ubah_barang_rusak&id_barang=$id_barang&result=failed");
    }
}

function hapus_barang($id){
    $delete = mysql_query("DELETE FROM barang WHERE kode_barang = '$id'");
    if($delete){
        header("location:../../index.php?modul=barang&submodul=tampil_barang&result=success_h");
    } else {
        header("location:../../index.php?modul=barang&submodul=tampil_barang&result=failed_h");
    }
}

function simpan_jenis_barang($jenis_barang){
    if($jenis_barang == ""){
        header("location:../../index.php?modul=barang&submodul=tambah_jenis_barang&result=failed");
        return;
    }
    $insert = mysql_query("INSERT INTO jenis_barang VALUES(null,'$jenis_barang')");

    if($insert){
        header("location:../../index.php?modul=barang&submodul=tambah_jenis_barang&result=success");
    } else {
        header("location:../../index.php?modul=barang&submodul=tambah_jenis_barang&result=failed");
    }
}

function ubah_jenis_barang($kode_jenis, $jenis_barang){
    $update = mysql_query("UPDATE jenis_barang SET jenis_barang='$jenis_barang' WHERE kode_jenis = '$kode_jenis'");

    if($update){
        header("location:../../index.php?modul=barang&submodul=tampil_jenis_barang&result=success");
    } else {
        header("location:../../index.php?modul=barang&submodul=tampil_jenis_barang&result=failed");
    }
}

function hapus_jenis_barang($id){
    $delete = mysql_query("DELETE FROM jenis_barang WHERE kode_jenis = '$id'");
    if($delete){
        header("location:../../index.php?modul=barang&submodul=tampil_jenis_barang&result=success_h");
    } else {
        header("location:../../index.php?modul=barang&submodul=tampil_jenis_barang&result=failed_h");
    }
}

if($action_am == "simpan_barang"){
    simpan_barang($id_barang_am,$nama_barang_am,$satuan_am,$jumlah_am,$harga_jual_am,$jenis_barang);
} else if($action_am == "ubah_barang"){
    ubah_barang($nama_barang_am,$satuan_am,$jumlah_am,$harga_jual_am,$id_barang_am);
} else if($action_am == "ubah_barang_rusak"){
    ubah_barang_rusak($jumlah_rusak_am, $id_barang_am);
} else if($action_am == "hapus_barang"){
    hapus_barang($id_barang_am);
} else if($action_am == "simpan_jenis_barang"){
    simpan_jenis_barang($jenis_barang);
} else if($action_am == "ubah_jenis_barang"){
    ubah_jenis_barang($kode_jenis, $jenis_barang);
} else if($action_am == "hapus_jenis_barang"){
    hapus_jenis_barang($id);
}
?>