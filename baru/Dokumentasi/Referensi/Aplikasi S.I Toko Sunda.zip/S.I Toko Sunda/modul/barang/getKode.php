<?php

include("../../lib_php/connection.php");

$cek = "kosong";
if(isset($_POST['kode'])){
	$kode = $_POST['kode'];
}

$query = mysql_query("SELECT * FROM barang WHERE kode_barang = '$kode' ");

if(mysql_num_rows($query) > 0){
    echo "ada";
}
?>