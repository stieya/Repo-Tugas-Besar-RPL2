<div class="head">
    <div class="info">
        <h1>Tambah Barang</h1>
    </div>

    <div class="search">
        <form action="#" method="post">
            <input type="text" placeholder="search..."/>
            <button type="submit"><span class="i-calendar"></span></button>
            <button type="submit"><span class="i-magnifier"></span></button>
        </form>
    </div>
</div>
<div class="content">
    <div class="row-fluid">
        <!-- Code Here -->

        <div class="span8">
            <?php
            $result = "";
            if(isset($_GET['result'])){
                $result = $_GET['result'];
            }

            if($result == 'success'){
            ?>
            <div class="alert alert-success">
                <strong>Berhasil tambah barang.</strong>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php
            } else if($result == 'failed'){
            ?>
            <div class="alert alert-error">
                <strong>Gagal tambah barang!</strong>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
            <?php
            }
            ?>

            <form action="modul/barang/action_barang.php" method="get" enctype="multipart/form-data" onsubmit="return cekValidBarang()">
            <div class="block">
                <div class="head">
                    <h2>Form Tambah Barang</h2>
                </div>
                <div class="content np">
                    <input type="hidden" name="action" value="simpan_barang">
                    <div class="controls-row">
                        <div class="span3">Kode Barang</div>
                        <div class="span9"><input type="text" id="id_barang" name="id_barang" onchange="cekKodeBarang()" onkeyup="cekKodeBarang()" placeholder="Kode Barang"/><span id="warning1" ></span></div>
                    </div>
                    <div class="controls-row">
                        <div class="span3">Nama Barang</div>
                        <div class="span9"><input type="text" id="nama_barang" name="nama_barang" placeholder="Nama Barang" onchange="cekNamaBarang()" onkeyup="cekNamaBarang()"/><span id="warning2" ></span></div>
                    </div>
                    <div class="controls-row">
                        <div class="span3">Jenis Barang</div>
                        <div class="span9">
                            <select class="select2" style="width: 220px;" name="jenis_barang" id="jenis_barang" onchange="cekJenisBarang()" onkeyup="cekJenisBarang()">
                                <?php
                                $query = mysql_query("SELECT * FROM jenis_barang");
                                while($data = mysql_fetch_array($query)){
                                    echo '<option value="'.$data['kode_jenis'].'">'.$data['jenis_barang'].'</option>';
                                }
                                ?>
                            </select>
                            <span id="warning3" ></span>
                        </div>
                    </div>
                    <div class="controls-row">
                        <div class="span3">Satuan</div>
                        <div class="span9"><input type="text" id="satuan" name="satuan" placeholder="Satuan" onchange="cekSatuanBarang()" onkeyup="cekSatuanBarang()"/><span id="warning4" ></span></div>
                    </div>
                    <div class="controls-row">
                        <div class="span3">Jumlah</div>
                        <div class="span9"><input type="text" id="jumlah" name="jumlah" placeholder="Jumlah" onchange="cekJumlahBarang()" onkeyup="cekJumlahBarang()"/><span id="warning5" ></span></div>
                    </div>
                    <div class="controls-row">
                        <div class="span3">Harga Jual</div>
                        <div class="span9"><input type="text" id="harga_jual" name="harga_jual" placeholder="Harga Jual" onchange="cekHargaBarang()" onkeyup="cekHargaBarang()"/><span id="warning6" ></span></div>
                    </div>
                </div>
                <div class="footer">
                    <div class="side fr">
                        <input type="submit" class="btn btn-primary" value="Simpan">
                    </div>
                </div>
            </div>
            </form>
        </div>

    </div>
</div>