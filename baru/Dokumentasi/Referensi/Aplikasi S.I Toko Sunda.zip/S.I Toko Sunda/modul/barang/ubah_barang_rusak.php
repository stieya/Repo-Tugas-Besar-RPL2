<?php
$id_barang_um = "";
if(isset($_GET['id_barang'])){
    $id_barang_um = $_GET['id_barang'];
}
$select = mysql_query("SELECT * FROM barang JOIN barang_rusak USING (kode_barang) WHERE kode_barang = '$id_barang_um'");
$data = mysql_fetch_array($select);
?>
<div class="head">
    <div class="info">
        <h1>Ubah Barang Rusak</h1>
    </div>

    <div class="search">
        <form action="#" method="post">
            <input type="text" placeholder="search..."/>
            <button type="submit"><span class="i-calendar"></span></button>
            <button type="submit"><span class="i-magnifier"></span></button>
        </form>
    </div>
</div>
<div class="content">
    <div class="row-fluid">

        <div class="span6">
            <?php
            $result = "";
            if(isset($_GET['result'])){
                $result = $_GET['result'];
            }

            if($result == 'success'){
                ?>
                <div class="alert alert-success">
                    <strong>Berhasil ubah barang rusak.</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            } else if($result == 'failed'){
                ?>
                <div class="alert alert-error">
                    <strong>Gagal ubah barang rusak!</strong>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
            <?php
            }
            ?>

            <form action="modul/barang/action_barang_rusak.php" method="get" enctype="multipart/form-data">
            <div class="block">
                <div class="head">
                    <h2>Form Ubah Barang Rusak</h2>
                </div>
                <div class="content np">
                    <input type="hidden" name="id_barang" value="<?php echo $id_barang_um;?>">
                    <input type="hidden" name="action" value="ubah_barang">
                    <div class="controls-row">
                        <div class="span3">Nama Barang</div>
                        <div class="span9"><input type="text" name="nama_barang" placeholder="Nama Barang" value="<?php echo $data['nama_barang'];?>"/></div>
                    </div>
                    <div class="controls-row">
                        <div class="span3">Jumlah Rusak</div>
                        <div class="span9">
                            <input type="text" name="jumlah_rusak" placeholder="Jumlah Rusak" value="<?php echo $data['jumlah_rusak'];?>"/>
                        </div>
                    </div>
                </div>
                <div class="footer">
                    <div class="side fr">
                        <a href="index.php?modul=barang&submodul=daftar_barang_rusak" class="btn btn-danger" type="button" style="padding: 2px 15px 2px 15px">Batal</a>
                        <input type="submit" class="btn btn-primary" value="Simpan">
                    </div>
                </div>
            </div>
            </form>
        </div>

    </div>
</div>