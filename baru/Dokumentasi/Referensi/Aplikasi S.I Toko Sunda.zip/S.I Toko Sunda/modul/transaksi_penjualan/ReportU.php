<?php
include("../../lib_php/connection.php");

$kategori2 = '';
$tanggal2 = '';
if(isset($_POST['kategori2']) && isset($_POST['tanggal2']))
{
   $kategori2 = $_POST['kategori2'];
   $tanggal2 = $_POST['tanggal2'];
   if ($kategori2 == 'harian')
   {
      $query = "SELECT tj.no_transaksi, b.nama_barang, dtj.jumlah_beli, CONCAT('Rp. ', FORMAT(harga,2)), CONCAT('Rp. ', FORMAT(total,2)) FROM transaksi_jual tj JOIN detail_transaksi_jual dtj ON (tj.no_transaksi = dtj.no_transaksi) JOIN barang b USING(kode_barang) WHERE DATE_FORMAT(`tanggal_transaksi`, '%m/%d/%Y') LIKE '%$tanggal2%' ORDER BY tj.no_transaksi";
      $result = mysql_query($query);
      $data = array();

      while ($row = mysql_fetch_assoc($result)) 
      {
         array_push($data, $row);
      }

      $judul = "LAPORAN TRANSAKSI " . $tanggal2;
      $header = array( array("label"=>"Kode Transaksi","length"=>30,"align"=>"C"),
                     array("label"=>"Nama Brg","length"=>50,"align"=>"C"),
                     array("label"=>"Jumlah","length"=>30,"align"=>"C"),
                     array("label"=>"Harga","length"=>30,"align"=>"C"),
                     array("label"=>"Total","length"=>30,"align"=>"C"));       
   }
   else if ($kategori2 == 'bulanan')
   {
      $tanggal2 = SUBSTR($tanggal2,0,2) . '' . SUBSTR($tanggal2, -5, 5);
      $query = "SELECT tj.no_transaksi, tj.tanggal_transaksi, b.nama_barang, dtj.jumlah_beli, harga, total FROM transaksi_jual tj JOIN detail_transaksi_jual dtj ON (tj.no_transaksi = dtj.no_transaksi) JOIN barang b USING(kode_barang) WHERE DATE_FORMAT(`tanggal_transaksi`, '%m/%Y') LIKE '%$tanggal2%' ORDER BY tj.no_transaksi";
      $result = mysql_query($query);
      $data = array();

      while ($row = mysql_fetch_assoc($result)) 
      {
         array_push($data, $row);
      }

      $judul = "LAPORAN TRANSAKSI " . $tanggal2;
      $header = array( array("label"=>"Kode Transaksi","length"=>30,"align"=>"R"),
                     array("label"=>"Tanggal","length"=>30,"align"=>"C"),
                     array("label"=>"Nama Brg","length"=>50,"align"=>"C"),
                     array("label"=>"Jumlah","length"=>25,"align"=>"R"),
                     array("label"=>"Harga","length"=>25,"align"=>"R"),
                     array("label"=>"Total","length"=>25,"align"=>"R"));
   }

   require_once ("fpdf.php");
   $pdf = new FPDF();
   $pdf->AddPage();
   $pdf->SetFont('Arial','B','16');
   $pdf->Cell(0,20,$judul,'0',1,'C');
   $pdf->SetFont('Arial','','10');
   $pdf->setFillColor(255,0,0);
   $pdf->SetTextColor(255);
   $pdf->SetDrawColor(128,0,0);
   foreach($header as $kolom)
   {
      $pdf->Cell($kolom['length'],5,$kolom['label'],1,0,$kolom['align'],true);
   }
   $pdf->Ln();
   $pdf->SetFillColor(224,235,255);
   $pdf->SetTextColor(0);
   $pdf->SetFont('');
   $fill=false;
   foreach($data as $baris)
   {
      $i=0;
      foreach($baris as $cell)
      {
         $pdf->Cell($header[$i]['length'],5,$cell,1,0,'L',true);
         $i++;
      }
      $fill=!$fill;
      $pdf->Ln();
   }
   $pdf->Output();
}
                 		 
?>