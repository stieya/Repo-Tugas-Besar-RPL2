<?php
include("../../lib_php/connection.php");

   $judul = "TOKO SUNDA";
   $judul2 = "Jl. DipatiUkur No. 56";
   $judul3 = "Telp. 022-5653423";

   $query = "SELECT tanggal_transaksi, CONCAT('Rp. ', FORMAT(total,2)) FROM transaksi_jual ORDER BY no_transaksi DESC limit 1";
   $result = mysql_query($query);
   $row = mysql_fetch_assoc($result);
   $a1 = $row['tanggal_transaksi'];
   $a3 = $row["CONCAT('Rp. ', FORMAT(total,2))"];

   $query2 = "SELECT b.nama_barang, CONCAT('x',dtj.jumlah_beli), CONCAT('Rp. ', FORMAT((dtj.jumlah_beli*dtj.harga),2)) FROM detail_transaksi_jual dtj JOIN barang b USING(kode_barang) WHERE no_transaksi = (SELECT no_transaksi FROM transaksi_jual ORDER BY no_transaksi DESC limit 1)";
   $result2 = mysql_query($query2);
   $data2 = array();
   while ($row2 = mysql_fetch_assoc($result2)) 
   {
      array_push($data2, $row2);
   }

   $header2 = array( array("label"=>"                     Nama Brg","length"=>80,"align"=>"R"),
                     array("label"=>"    Jml","length"=>20,"align"=>"C"),
                     array("label"=>"Harga","length"=>50,"align"=>"R"));

   require_once ("fpdf.php");
   $pdf = new FPDF();
   $pdf->AddPage();
   $pdf->SetFont('Arial','B','12');
   $pdf->Cell(0,3,$a1,'0',1,'R');
   $pdf->Ln();

   $pdf->SetFont('Arial','B','16');
   $pdf->Cell(0,3,$judul,'0',1,'C');
   $pdf->Ln();

   $pdf->SetFont('Arial','B','16');
   $pdf->Cell(0,3,$judul2,'0',1,'C');
   $pdf->Ln();

   $pdf->SetFont('Arial','B','16');
   $pdf->Cell(0,3,$judul3,'0',1,'C');
   $pdf->Ln();
   
   $pdf->SetFont('Arial','B','16');
   $pdf->Cell(0,15,'===============================','0',1,'C');
   $pdf->Ln();

   $pdf->SetFillColor(255,255,255);
   $pdf->SetTextColor(0);
   foreach($header2 as $kolom)
   {
      $pdf->Cell($kolom['length'],6,$kolom['label'],0,0,$kolom['align'],true);
   }
   $pdf->Ln();

   $pdf->SetFillColor(255,255,255);
   $pdf->SetTextColor(0);
   $pdf->SetFont('');
   $fill=false;
   foreach($data2 as $baris)
   {
      $i=0;
      foreach($baris as $cell)
      {
         $pdf->Cell($header2[$i]['length'],6,$cell,0,0,$kolom['align'],true);
         $i++;
      }
      $fill=!$fill;
      $pdf->Ln();
   }

   $pdf->SetFont('Arial','','14');
   $pdf->Cell(0,3,'---------------------                            ','0',1,'R');
   $pdf->Ln();

   $pdf->SetFont('Arial','','14');
   $pdf->Cell(0,3,'Total :  '.$a3.'                              ','0',1,'R');
   $pdf->Ln();

   $pdf->SetFont('Arial','','14');
   $pdf->Cell(0,3,'Bayar :  '.''.'                                                      ','0',1,'R');
   $pdf->Ln();

   $pdf->SetFont('Arial','','14');
   $pdf->Cell(0,7.20,'Kembalian :  '.''.'                                                      ','0',1,'R');
   $pdf->Ln();

   $pdf->SetFont('Arial','B','16');
   $pdf->Cell(0,3,'===============================','0',1,'C');
   $pdf->Ln();

   $pdf->SetFont('Arial','','12');
   $pdf->Cell(0,3,'-- Terima Kasih --','0',1,'C');
   $pdf->Ln();

   $pdf->Output();

   
                      		 
?>