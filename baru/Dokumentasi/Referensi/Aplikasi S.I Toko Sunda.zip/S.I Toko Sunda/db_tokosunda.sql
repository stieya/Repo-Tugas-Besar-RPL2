-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 09, 2014 at 11:22 AM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_tokosunda`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `kode_barang` varchar(13) NOT NULL,
  `nama_barang` varchar(45) NOT NULL,
  `satuan` varchar(25) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `kode_jenis` int(11) NOT NULL,
  PRIMARY KEY (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kode_barang`, `nama_barang`, `satuan`, `jumlah`, `harga_jual`, `kode_jenis`) VALUES
('BCW01', 'Bako Cap Wayang', 'Pcs', 75, 6000, 8),
('BR10221', 'Bir Bintang', 'Botol', 88, 21000, 7),
('CE10003', 'CapEnak Kaleng', 'Kaleng', 995, 7000, 3),
('CE1002', 'CapEnak sachet', 'Sachet', 90, 1200, 3),
('DC10001', 'DenCow', 'Dus', 88, 25000, 3),
('GA001', 'Gasoline', 'Pcs', 90, 2500, 10),
('GU001', 'Gulaku', 'Kg', 89, 9000, 0),
('KP001', 'Kopi ABC Susu', 'PCS', 98, 1000, 0),
('KP002', 'Kopi Good Day', 'PCS', 96, 1000, 2),
('KP9001', 'GooddayMoca', 'Pcs', 100, 1000, 2),
('KW1000', 'Kopi luwak', 'Bungkus', 1, 800000, 2),
('RT2001', 'Rotiku', 'Pcs', 97, 5000, 9),
('SM10001', 'Dji sum su', 'Bungkus', 92, 12000, 8),
('SM2002', 'Sampoerna Mild', 'Bungkus', 96, 14000, 8),
('SM3001', 'Sampoerna Kretek', 'Bungkus', 95, 8700, 8),
('SN10001', 'Sunco ', 'Liter', 98, 10000, 6),
('SN2001', 'Sania', 'Liter', 98, 9900, 6),
('SU001', 'Susu Bendera Coklat', 'Dus', 4, 62000, 0),
('SU8001', 'SGM', 'Bungkus', 98, 12500, 3),
('TW10002', 'Roti Tawar', 'Bungkus', 92, 7800, 9);

-- --------------------------------------------------------

--
-- Table structure for table `barang_rusak`
--

CREATE TABLE IF NOT EXISTS `barang_rusak` (
  `kode_barang` varchar(13) NOT NULL,
  `jumlah_rusak` int(11) NOT NULL,
  KEY `kode_barang` (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang_rusak`
--

INSERT INTO `barang_rusak` (`kode_barang`, `jumlah_rusak`) VALUES
('GU001', 6),
('SU001', 2),
('BCW01', 1),
('DC10001', 2),
('KW1000', 1),
('SM10001', 1),
('CE1002', 5),
('SU001', 1),
('KP9001', 2),
('BR10221', 2);

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi_jual`
--

CREATE TABLE IF NOT EXISTS `detail_transaksi_jual` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_transaksi` int(11) NOT NULL,
  `kode_barang` varchar(13) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `no_transaksi` (`no_transaksi`),
  KEY `kode_barang` (`kode_barang`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=88 ;

--
-- Dumping data for table `detail_transaksi_jual`
--

INSERT INTO `detail_transaksi_jual` (`id`, `no_transaksi`, `kode_barang`, `jumlah_beli`, `harga`) VALUES
(2, 2, 'GU001', 2, 9000),
(3, 3, 'KP002', 1, 1000),
(4, 3, 'SU001', 1, 62000),
(7, 5, 'KW1000', 1, 800000),
(8, 6, 'CE1002', 3, 1200),
(9, 6, 'DC10001', 2, 25000),
(10, 6, 'GU001', 1, 9000),
(11, 7, 'BCW01', 2, 6000),
(12, 7, 'BR10221', 1, 21000),
(14, 8, 'KW1000', 1, 800000),
(15, 8, 'GA001', 1, 2500),
(16, 8, 'SM10001', 2, 12000),
(17, 9, 'DC10001', 1, 25000),
(18, 9, 'BR10221', 2, 21000),
(19, 9, 'RT2001', 2, 5000),
(20, 9, 'TW10002', 1, 7800),
(24, 10, 'GA001', 1, 2500),
(25, 11, 'GU001', 2, 9000),
(26, 11, 'CE1002', 3, 1200),
(28, 12, 'KP002', 2, 1000),
(29, 12, 'RT2001', 1, 5000),
(31, 13, 'GA001', 1, 2500),
(32, 13, 'BCW01', 1, 6000),
(34, 14, 'SU8001', 1, 12500),
(35, 15, 'KW1000', 2, 800000),
(36, 16, 'SM3001', 2, 8700),
(37, 16, 'SN10001', 1, 10000),
(39, 17, 'CE10003', 2, 7000),
(40, 17, 'GU001', 2, 9000),
(42, 18, 'SN2001', 2, 9900),
(43, 19, 'DC10001', 1, 25000),
(44, 20, 'CE1002', 3, 1200),
(45, 20, 'BR10221', 1, 21000),
(46, 20, 'KP001', 2, 1000),
(47, 21, 'SM2002', 1, 14000),
(48, 21, 'BR10221', 1, 21000),
(50, 22, 'SU8001', 1, 12500),
(51, 22, 'SN10001', 1, 10000),
(53, 23, 'BCW01', 2, 6000),
(54, 23, 'DC10001', 4, 25000),
(55, 23, 'SM3001', 3, 8700),
(56, 24, 'BR10221', 1, 21000),
(57, 24, 'CE10003', 1, 7000),
(59, 25, 'GU001', 1, 9000),
(60, 26, 'BR10221', 2, 21000),
(61, 27, 'BCW01', 1, 6000),
(62, 28, 'BCW01', 3, 6000),
(63, 29, 'BCW01', 4, 6000),
(64, 32, 'BCW01', 3, 6000),
(65, 33, 'BCW01', 4, 6000),
(66, 34, 'SM2002', 3, 14000),
(67, 35, 'BCW01', 1, 6000),
(68, 36, 'BR10221', 2, 21000),
(69, 37, 'SM10001', 1, 12000),
(70, 38, 'CE1002', 1, 1200),
(71, 39, 'BCW01', 1, 6000),
(72, 39, 'BR10221', 1, 21000),
(74, 40, 'BCW01', 1, 6000),
(75, 40, 'BR10221', 1, 21000),
(76, 40, 'DC10001', 2, 25000),
(77, 40, 'SM10001', 5, 12000),
(78, 40, 'TW10002', 7, 7800),
(81, 41, 'BCW01', 1, 6000),
(82, 41, 'CE10003', 2, 7000),
(83, 41, 'GA001', 4, 2500),
(84, 42, 'GU001', 5, 9000),
(85, 43, 'BCW01', 1, 6000),
(86, 43, 'DC10001', 2, 25000),
(87, 43, 'GA001', 3, 2500);

-- --------------------------------------------------------

--
-- Table structure for table `detail_transaksi_suplai`
--

CREATE TABLE IF NOT EXISTS `detail_transaksi_suplai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_suplai` int(11) NOT NULL,
  `kode_barang` varchar(13) NOT NULL,
  `harga_suplai` int(11) NOT NULL,
  `jumlah_suplai` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `no_suplai` (`no_suplai`),
  KEY `kode_barang` (`kode_barang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `detail_transaksi_suplai`
--

INSERT INTO `detail_transaksi_suplai` (`id`, `no_suplai`, `kode_barang`, `harga_suplai`, `jumlah_suplai`) VALUES
(1, 7, 'GU001', 5000, 5),
(2, 7, 'GU001', 8000, 9),
(3, 8, 'GU001', 1000, 6),
(4, 8, 'KP001', 8000, 1),
(5, 8, 'SU001', 8000, 1),
(6, 9, 'SU001', 2000, 10),
(7, 10, 'GU001', 9000, 20),
(8, 11, 'KP001', 1000, 5),
(9, 11, 'SU001', 1500, 15),
(10, 12, 'SM10001', 9900, 20),
(11, 12, 'GA001', 7900, 100),
(12, 13, 'RT2001', 4500, 100),
(13, 14, 'SM2002', 8990, 100),
(14, 15, 'SU8001', 9000, 100),
(15, 16, 'KP001', 10000, 100),
(16, 16, 'KW1000', 500, 12);

-- --------------------------------------------------------

--
-- Table structure for table `diskon`
--

CREATE TABLE IF NOT EXISTS `diskon` (
  `kode_diskon` int(11) NOT NULL AUTO_INCREMENT,
  `kode_barang` varchar(13) NOT NULL,
  `tanggal_awal` date NOT NULL,
  `tanggal_akhir` date NOT NULL,
  `diskon` decimal(10,0) NOT NULL,
  PRIMARY KEY (`kode_diskon`),
  KEY `kode_barang` (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `diskon`
--


-- --------------------------------------------------------

--
-- Table structure for table `jenis_barang`
--

CREATE TABLE IF NOT EXISTS `jenis_barang` (
  `kode_jenis` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_barang` varchar(30) NOT NULL,
  PRIMARY KEY (`kode_jenis`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jenis_barang`
--

INSERT INTO `jenis_barang` (`kode_jenis`, `jenis_barang`) VALUES
(2, 'Kopi'),
(3, 'Susu'),
(6, 'Minyak Goreng'),
(7, 'Minuman'),
(8, 'Rokok'),
(9, 'Roti'),
(10, 'Lain-lain');

-- --------------------------------------------------------

--
-- Table structure for table `modul`
--

CREATE TABLE IF NOT EXISTS `modul` (
  `id_modul` int(11) NOT NULL AUTO_INCREMENT,
  `nama_modul` varchar(20) NOT NULL,
  `hak_akses` varchar(10) NOT NULL,
  `publish` varchar(1) NOT NULL,
  `id_user` varchar(15) NOT NULL,
  `icon` varchar(30) NOT NULL,
  PRIMARY KEY (`id_modul`),
  UNIQUE KEY `nama_modul` (`nama_modul`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `modul`
--

INSERT INTO `modul` (`id_modul`, `nama_modul`, `hak_akses`, `publish`, `id_user`, `icon`) VALUES
(5, 'Pengaturan', 'super', 'T', 'admin', 'img/icons/settings.png'),
(48, 'Barang', 'super', 'Y', 'admin', ''),
(50, 'Transaksi Suplai', 'admin', 'Y', 'admin', ''),
(51, 'Transaksi Penjualan', 'admin', 'Y', 'admin', ''),
(52, 'Distributor', 'admin', 'Y', 'admin', ''),
(53, 'Pengguna', 'super', 'Y', 'admin', 'img/icons/user.png');

-- --------------------------------------------------------

--
-- Table structure for table `pemasok`
--

CREATE TABLE IF NOT EXISTS `pemasok` (
  `id_pemasok` varchar(8) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_telepon` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_pemasok`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemasok`
--

INSERT INTO `pemasok` (`id_pemasok`, `nama`, `no_telepon`) VALUES
('A001', 'Unilever', 888),
('D002', 'Indofood', 23983120),
('DJ1455', 'Djarum Tbk', 9045666),
('GG002', 'PT Gudang garam', 8000342),
('NU100', 'Nina', 92399),
('OR001', 'Orangtua', 90882),
('RE345', 'Reni astuti', 890067),
('SM0034', 'Sampoerna Tbk', 890001),
('UL001', 'Ultrajaya', 219999),
('WG002', 'Wingsfood', 89009);

-- --------------------------------------------------------

--
-- Table structure for table `submodul`
--

CREATE TABLE IF NOT EXISTS `submodul` (
  `id_submodul` int(11) NOT NULL AUTO_INCREMENT,
  `nama_submodul` varchar(20) NOT NULL,
  `link` varchar(50) NOT NULL,
  `hak_akses` varchar(10) NOT NULL,
  `publish` varchar(1) NOT NULL,
  `id_modul` int(11) NOT NULL,
  `id_user` varchar(15) NOT NULL,
  PRIMARY KEY (`id_submodul`),
  KEY `id_modul` (`id_modul`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Dumping data for table `submodul`
--

INSERT INTO `submodul` (`id_submodul`, `nama_submodul`, `link`, `hak_akses`, `publish`, `id_modul`, `id_user`) VALUES
(15, 'Tambah Modul', 'submodul=tambah_modul', 'admin', 'Y', 5, 'admin'),
(16, 'Daftar Modul', 'submodul=daftar_modul', 'admin', 'Y', 5, 'admin'),
(17, 'Daftar Submodul', 'submodul=daftar_submodul', 'admin', 'Y', 5, 'admin'),
(18, 'Tambah Submodul', 'submodul=tambah_submodul', 'admin', 'Y', 5, 'admin'),
(45, 'Tambah Barang', 'submodul=tambah_barang', 'super', 'Y', 48, 'admin'),
(48, 'Tampil Barang', 'submodul=tampil_barang', 'super', 'Y', 48, 'admin'),
(49, 'Tambah Transaksi', 'submodul=tambah_transaksi', 'super', 'Y', 50, 'admin'),
(50, 'Tampil Transaksi', 'submodul=tampil_transaksi', 'super', 'Y', 50, 'admin'),
(51, 'Tambah Transaksi', 'submodul=tambah_transaksi', 'super', 'Y', 51, 'admin'),
(53, 'Tampil Transaksi', 'submodul=tampil_transaksi', 'super', 'Y', 51, 'admin'),
(54, 'Tambah Distributor', 'submodul=tambah_distributor', 'super', 'Y', 52, 'admin'),
(56, 'Tampil Distributor', 'submodul=tampil_distributor', 'super', 'Y', 52, 'admin'),
(57, 'Tambah Pengguna', 'submodul=tambah_pengguna', 'super', 'Y', 53, 'admin'),
(58, 'Tampil Pengguna', 'submodul=tampil_pengguna', 'super', 'Y', 53, 'admin'),
(59, 'Tampil Barang Rusak', 'submodul=daftar_barang_rusak', 'super', 'Y', 48, 'admin'),
(60, 'Tambah Barang Rusak', 'submodul=tambah_barang_rusak', 'super', 'Y', 48, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_jual`
--

CREATE TABLE IF NOT EXISTS `transaksi_jual` (
  `no_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_transaksi` date NOT NULL,
  `total` int(11) NOT NULL,
  `id_user` varchar(15) NOT NULL,
  PRIMARY KEY (`no_transaksi`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `transaksi_jual`
--

INSERT INTO `transaksi_jual` (`no_transaksi`, `tanggal_transaksi`, `total`, `id_user`) VALUES
(2, '2014-02-08', 18000, 'admin'),
(3, '2014-01-08', 63000, 'admin'),
(5, '2014-01-08', 800000, 'admin'),
(6, '2014-01-08', 62600, 'admin'),
(7, '2014-01-08', 33000, 'admin'),
(8, '2014-01-08', 826500, 'admin'),
(9, '2014-01-08', 84800, 'admin'),
(10, '2014-01-08', 2500, 'admin'),
(11, '2014-01-08', 21600, 'admin'),
(12, '2014-01-08', 7000, 'admin'),
(13, '2014-01-08', 8500, 'admin'),
(14, '2014-01-08', 12500, 'admin'),
(15, '2014-01-08', 1600000, 'admin'),
(16, '2014-01-08', 27400, 'admin'),
(17, '2014-01-08', 32000, 'admin'),
(18, '2014-01-08', 19800, 'admin'),
(19, '2014-01-08', 25000, 'admin'),
(20, '2014-01-08', 26600, 'admin'),
(21, '2014-01-08', 35000, 'admin'),
(22, '2014-01-08', 22500, 'admin'),
(23, '2014-01-08', 138100, 'admin'),
(24, '2014-01-09', 28000, 'admin'),
(25, '2014-01-09', 9000, 'admin'),
(26, '2014-01-09', 42000, 'admin'),
(27, '2014-01-09', 6000, 'admin'),
(28, '2014-01-09', 18000, 'admin'),
(29, '2014-01-09', 24000, 'admin'),
(30, '2014-01-09', 0, 'admin'),
(31, '2014-01-09', 0, 'admin'),
(32, '2014-01-09', 18000, 'admin'),
(33, '2014-01-09', 24000, 'admin'),
(34, '2014-01-09', 42000, 'admin'),
(35, '2014-01-09', 6000, 'admin'),
(36, '2014-01-09', 42000, 'admin'),
(37, '2014-01-09', 12000, 'admin'),
(38, '2014-01-09', 1200, 'admin'),
(39, '2014-01-09', 27000, 'admin'),
(40, '2014-01-09', 191600, 'admin'),
(41, '2014-01-09', 30000, 'admin'),
(42, '2014-01-09', 45000, 'admin'),
(43, '2014-01-09', 63500, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_suplai`
--

CREATE TABLE IF NOT EXISTS `transaksi_suplai` (
  `no_suplai` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal_suplai` date NOT NULL,
  `id_pemasok` varchar(8) NOT NULL,
  `id_user` varchar(15) NOT NULL,
  PRIMARY KEY (`no_suplai`),
  KEY `id_pemasok` (`id_pemasok`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `transaksi_suplai`
--

INSERT INTO `transaksi_suplai` (`no_suplai`, `tanggal_suplai`, `id_pemasok`, `id_user`) VALUES
(7, '2014-01-06', 'A001', 'admin'),
(8, '2014-01-06', 'A001', 'admin'),
(9, '2014-01-06', 'A001', 'admin'),
(10, '2014-01-08', 'A001', 'admin'),
(11, '2014-01-08', 'A001', 'admin'),
(12, '2014-01-08', 'GG002', 'admin'),
(13, '2014-01-08', 'NU100', 'admin'),
(14, '2014-01-08', 'DJ1455', 'admin'),
(15, '2014-01-08', 'UL001', 'admin'),
(16, '2014-01-08', 'WG002', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id_user` varchar(15) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `hak_akses` varchar(15) NOT NULL,
  `password` varchar(32) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `hak_akses`, `password`) VALUES
('admin', 'Admin', 'super', '827ccb0eea8a706c4c34a16891f84e7b'),
('Andrew', 'Andrew', 'super', 'd914e3ecf6cc481114a3f534a5faf90b'),
('handoyo', 'handoyo', 'super', '202cb962ac59075b964b07152d234b70'),
('joko', 'Joko Purnomo A', 'admin', '827ccb0eea8a706c4c34a16891f84e7b'),
('oji', 'oji', 'super', '54b2aa1988fc565e35c6c8155a28d2ec'),
('zaky', 'zaky', 'super', 'c20ad4d76fe97759aa27a0c99bff6710');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang_rusak`
--
ALTER TABLE `barang_rusak`
  ADD CONSTRAINT `barang_rusak_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `detail_transaksi_jual`
--
ALTER TABLE `detail_transaksi_jual`
  ADD CONSTRAINT `detail_transaksi_jual_ibfk_3` FOREIGN KEY (`no_transaksi`) REFERENCES `transaksi_jual` (`no_transaksi`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_transaksi_jual_ibfk_4` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `detail_transaksi_suplai`
--
ALTER TABLE `detail_transaksi_suplai`
  ADD CONSTRAINT `detail_transaksi_suplai_ibfk_8` FOREIGN KEY (`no_suplai`) REFERENCES `transaksi_suplai` (`no_suplai`) ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_transaksi_suplai_ibfk_9` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON UPDATE CASCADE;

--
-- Constraints for table `diskon`
--
ALTER TABLE `diskon`
  ADD CONSTRAINT `diskon_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `modul`
--
ALTER TABLE `modul`
  ADD CONSTRAINT `modul_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON UPDATE CASCADE;

--
-- Constraints for table `submodul`
--
ALTER TABLE `submodul`
  ADD CONSTRAINT `submodul_ibfk_2` FOREIGN KEY (`id_modul`) REFERENCES `modul` (`id_modul`) ON UPDATE CASCADE,
  ADD CONSTRAINT `submodul_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_jual`
--
ALTER TABLE `transaksi_jual`
  ADD CONSTRAINT `transaksi_jual_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON UPDATE CASCADE;

--
-- Constraints for table `transaksi_suplai`
--
ALTER TABLE `transaksi_suplai`
  ADD CONSTRAINT `transaksi_suplai_ibfk_1` FOREIGN KEY (`id_pemasok`) REFERENCES `pemasok` (`id_pemasok`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
