-- MySQL dump 10.13  Distrib 5.5.34, for Linux (x86_64)
--
-- Host: localhost    Database: ozantcom_emagang
-- ------------------------------------------------------
-- Server version	5.5.34-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_comment_list`
--

DROP TABLE IF EXISTS `t_comment_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_comment_list` (
  `id_comment_list` int(11) NOT NULL AUTO_INCREMENT,
  `id_job_list` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `isi_comment` varchar(100) DEFAULT NULL,
  `waktu_comment` datetime DEFAULT NULL,
  PRIMARY KEY (`id_comment_list`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_comment_list`
--

LOCK TABLES `t_comment_list` WRITE;
/*!40000 ALTER TABLE `t_comment_list` DISABLE KEYS */;
INSERT INTO `t_comment_list` (`id_comment_list`, `id_job_list`, `id_user`, `isi_comment`, `waktu_comment`) VALUES (21,35,20,'kerjainnnnn',NULL),(22,40,30,'test komentar','2014-07-06 17:23:29'),(23,49,25,'coba komentar','2014-07-13 16:43:34'),(24,49,36,'gk mau ahh',NULL),(25,NULL,36,'49',NULL),(26,49,25,'kata zakky komentar lagi tuh',NULL),(27,49,25,'kata zakky komentar lagi tuh',NULL),(28,49,25,'kata zakky komentar lagi tuh',NULL),(29,49,36,'haloo',NULL),(30,52,39,'Ini pak/bu hasil analisisnya.','2014-07-13 17:07:04'),(31,49,36,'coba y',NULL),(32,49,36,'masa sih huf',NULL),(33,49,36,'ah gk bener ini',NULL),(34,52,37,'baik, saya akan periksa. jika ada kesalahan akan saya kabari.',NULL),(35,49,36,'hai hai',NULL),(36,57,40,'Analisis sistem yang sedang berjalan pada perusahaan XYZ seperti apa?',NULL),(37,57,41,'untuk lebih jelasnya besok saya akan upload pak/bu file analisis yang sedang berjalannya','2014-07-14 05:36:49'),(38,61,44,'Analisis sistem yang sedang berjalan pada perusahaan XYZ seperti apa?',NULL);
/*!40000 ALTER TABLE `t_comment_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`ozantcom`@`localhost`*/ /*!50003 TRIGGER `tri_notif_studentcompany_diskusi_job_list` AFTER INSERT ON `t_comment_list` FOR EACH ROW begin
if ((select status_user from t_user tu where tu.id_user = new.id_user) = 'STUDENT') then
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select tu.id_user from t_job_list tjl join t_job_sheet tjs on (tjl.id_job_sheet = tjs.id_job_sheet) join t_perusahaan tp on (tp.id_perusahaan = tjs.id_perusahaan) join t_user tu on (tu.id_user = tp.id_user) where tjl.id_job_list = new.id_job_list), 
concat('Komentar baru dari job list ', (select head from t_job_list where id_job_list = new.id_job_list)), 
concat(concat('Komentar baru dari job list ', (select head from t_job_list where id_job_list = new.id_job_list)), concat(' dari student bernama ', (select ts.nama from t_student ts join t_user tu on (tu.id_user = ts.id_user) where tu.id_user = new.id_user))), 
current_timestamp, 
'0');
elseif ((select status_user from t_user tu where tu.id_user = new.id_user) = 'COMPANY') then
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select ts.id_user from t_job_list tjl join t_job_sheet tjs on (tjs.id_job_sheet = tjl.id_job_sheet) join t_student_job_sheet tsjs on (tsjs.id_job_sheet = tjs.id_job_sheet) join t_student ts on (ts.id_student = tsjs.id_student) where tjl.id_job_list = new.id_job_list), 
concat('Komentar baru dari job list ', (select head from t_job_list where id_job_list = new.id_job_list)), 
concat(concat('Komentar baru dari job list ', (select head from t_job_list where id_job_list = new.id_job_list)), concat(' dari perusahaan', ' ')), 
current_timestamp, 
'0');
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `t_job_list`
--

DROP TABLE IF EXISTS `t_job_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_job_list` (
  `id_job_list` int(11) NOT NULL AUTO_INCREMENT,
  `id_job_sheet` int(11) DEFAULT NULL,
  `head` varchar(100) DEFAULT NULL,
  `body` text,
  `file_perusahaan` varchar(100) DEFAULT NULL,
  `status` enum('Finished','Unclaimed') DEFAULT NULL,
  PRIMARY KEY (`id_job_list`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_job_list`
--

LOCK TABLES `t_job_list` WRITE;
/*!40000 ALTER TABLE `t_job_list` DISABLE KEYS */;
INSERT INTO `t_job_list` (`id_job_list`, `id_job_sheet`, `head`, `body`, `file_perusahaan`, `status`) VALUES (35,24,'Analisis Program','Analisis Programnya Sesuai Kebutuhan','class_(1).pdf','Unclaimed'),(36,24,'Implementasi','Pengkodean untuk program','class_(1).pdf','Unclaimed'),(37,24,'Testting','Pengetesan Program setelah dibuat',NULL,'Unclaimed'),(38,24,'Perbaikan','Apabila Tidak Terdapat Kesalah , maka Langsung Upload','class_(1).pdf','Unclaimed'),(39,24,'Upload Program','Upload Program Ke server','POSA-MVC.pdf','Unclaimed'),(40,25,'Analisis Kebutuhan','Lakukan Analisis Kebutuhan, Informasi lebih lanjut hubungi ibu epi',NULL,'Unclaimed'),(41,25,'Programming','Lakukan pengkodean dengan berbasis desktop menggunakan bahasa C#',NULL,'Unclaimed'),(43,25,'Design UI/UX','Lakukan Desain Interface menggunakan Tools Balsamic sebagai alat bantu pembuatan mockup aplikasi',NULL,'Unclaimed'),(44,33,'Penggantian kabel','Penggantian kabel disetiap tower',NULL,'Unclaimed'),(45,33,'Penggantian baut','Penggantian baut di setiap daerah',NULL,'Unclaimed'),(54,38,'Class Diagram','Deskripsi Job Sheet','carhartl-jquery-cookie-v1.4_.1-0-g7f88a4e_.zip','Finished'),(48,35,'Pembersihan lingkungan gardu','Membersihkan lingkungan di setiap gardu',NULL,'Unclaimed'),(49,36,'Analisis Data Kepegawaian','Disini mengurus bagian data kepegawaian',NULL,'Unclaimed'),(50,35,'Pemeriksaan keamanan gardu','Pemeriksaan keamanan gardu',NULL,'Unclaimed'),(51,36,'Peramalan Data Kepegawaian','Bagian ini untuk membuat peramalan pegawai',NULL,'Unclaimed'),(52,38,'Analisis Kebutuhan','Analisis kebutuhan fungsional dan non fungsional.','carhartl-jquery-cookie-v1.4_.1-0-g7f88a4e_.zip','Finished'),(53,38,'Use Case','Pembuatan use case diagram.',NULL,'Finished'),(55,39,'Analisis Sistem yang Berjalan','Analisis sistem yang sedang berjalan.',NULL,'Unclaimed'),(60,39,'Analisis Kebutuhan','Deskripsi Job Sheet',NULL,'Unclaimed'),(61,41,'Analisis Sistem yang Berjalan','Pada tahap ini dilakukan analisis pada sistem yang sedang berjalan.','SIPG.zip','Unclaimed'),(57,40,'Analisis Sistem yang Berjalan','Analisis sistem yang sedang berjalan pada suatu perusahaan.','SIPG.zip','Unclaimed'),(59,40,'Analisis Fungsional','Analisis kebutuhan fungsional dan non fungsional sistem.',NULL,'Unclaimed'),(62,41,'Analisis Kebutuhan','Pada tahap ini dilakukan pengumpulan kebutuhan, baik kebutuhan fungsional maupun non fungsional.',NULL,'Unclaimed'),(63,42,'Analisis Sistem yang Berjalan','Analisis sistem yang sedang berjalan pada UPI CELL',NULL,'Unclaimed');
/*!40000 ALTER TABLE `t_job_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`ozantcom`@`localhost`*/ /*!50003 trigger tri_notif_student_selesai_job_list
after update on t_job_list
for each row 
begin
if (new.status = 'Finished') then
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select id_user from t_student_job_list tsjl join t_student ts on (tsjl.id_student = ts.id_student) where tsjl.id_job_list = new.id_job_list), 
'Perubahan status job list ', 
concat(concat('Status untuk job list ', new.head), concat(' telah selesai ', ' ')), 
current_timestamp, 
'0');
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `t_job_sheet`
--

DROP TABLE IF EXISTS `t_job_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_job_sheet` (
  `id_job_sheet` int(11) NOT NULL AUTO_INCREMENT,
  `id_perusahaan` int(11) NOT NULL,
  `nama_job_sheet` varchar(100) NOT NULL,
  `deskripsi_job_sheet` text NOT NULL,
  `id_jurusan` int(11) DEFAULT NULL,
  `tanggal_posting` datetime NOT NULL,
  `tanggal_akhir` datetime DEFAULT NULL,
  `status` enum('Ongoing','Finished','Unclaimed','Hidden') NOT NULL,
  `durasi` int(11) NOT NULL,
  PRIMARY KEY (`id_job_sheet`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_job_sheet`
--

LOCK TABLES `t_job_sheet` WRITE;
/*!40000 ALTER TABLE `t_job_sheet` DISABLE KEYS */;
INSERT INTO `t_job_sheet` (`id_job_sheet`, `id_perusahaan`, `nama_job_sheet`, `deskripsi_job_sheet`, `id_jurusan`, `tanggal_posting`, `tanggal_akhir`, `status`, `durasi`) VALUES (24,12,'Kumpulkan Tugas Atol','Dikerjakan Secepatnya',0,'2014-07-06 13:22:29',NULL,'Ongoing',1),(25,16,'Membuat S.I Perhotelan (ASTON Bandung)','Dibutuhkan Mahasiswa/i D3/S1 yang berlokasi di kota Garut untuk dapat magang di perusahaan kami dengan pekerjaan menghandle proyek perangkat lunak sistem informasi perhotelan di kota Bandung',16,'2014-07-06 15:08:44',NULL,'Ongoing',3),(26,16,'Pembuatan Aplikasi Game Android','Dibutuhkan mahasiswa/i yang berlokasi di kota Bandung jurusan teknik informatika untuk membuat proyek perangkat lunak games sebagai media edukasi SDN 031 Cibadak, dibutuhkan segera',16,'2014-07-06 15:10:16',NULL,'Unclaimed',3),(27,17,'Bangun Jaringan Komputer  On site Blok Cepu','Dibutuhkan Mahasiswa/i yang ingin magang dan berlokasi di kota Balikpapan untuk dapat bergabung bersama tim IT pertamina membangun infrastruktur jaringan komputer on site blok cepu.',16,'2014-07-06 15:17:18',NULL,'Unclaimed',6),(28,17,'Admin Recruitment Karyawan','PT.Pertamina sedang melakukan rekrutmen karyawan selama 3 miggu di Jakarta, bagi mahasiswa/i yang ingin magang dan membantu dipersilahkan untuk daftar secepatnya.',17,'2014-07-06 15:19:14',NULL,'Unclaimed',3),(29,18,'Developing e-Billing System','Dibutuhkan Mahasiswa/i dari UNIKOM, ITB. ITHB, Telkom University untuk dapat magang di tempat kami untuk menghandle proyek e-billing speedy di kota baru parahyangan padalarang.',16,'2014-07-06 15:28:04',NULL,'Unclaimed',3),(30,19,'Kameramen magang','Megang kamera ama bummer',16,'2014-07-06 16:23:25',NULL,'Unclaimed',6),(31,20,'Networking','Deskripsi Job Sheet',0,'2014-07-06 16:49:05',NULL,'Unclaimed',3),(32,21,'Salesmen Junior','Deskripsi Job Sheet',0,'2014-07-06 16:50:07',NULL,'Unclaimed',3),(33,22,'Pemeliharan tower','Pemeliharaan tower di daerah cilegon',0,'2014-07-13 15:05:15',NULL,'Unclaimed',1),(39,24,'Pembanguan Aplikasi Zakat','Pembangunan sistem informasi pengolahan zakat yang juga mencangkup sadaqoh dan infaq.',16,'2014-07-13 19:45:52',NULL,'Ongoing',2),(35,22,'Pemeliharan gardu induk','Pemeliharan gardu induk di setiap daerah',0,'2014-07-13 15:13:55',NULL,'Unclaimed',1),(36,23,'Kepegawaian','Bagian ini mengurus data kepegawaian',16,'2014-07-13 15:16:22',NULL,'Ongoing',7),(37,25,'Bidang Marketing','Bekerja dibagian marketing',16,'2014-07-13 15:24:56',NULL,'Unclaimed',5),(38,24,'Pembangunan Web Site','Web site yang dibangun adalah web penjualan barang-barang elektronik.',16,'2014-07-13 15:37:39',NULL,'Finished',1),(40,26,'Aplikasi Pengelolaan Gaji','Aplikasi pengelolaan gaji bertujuan mempermudah dan membantu menangani sistem penggajian pada suatu instansi.',16,'2014-07-14 04:35:17',NULL,'Ongoing',3),(41,27,'Aplikasi Pengelolaan Gaji','Pembangunan aplikasi pengelolaan gaji.',16,'2014-07-14 11:10:18',NULL,'Ongoing',2),(42,24,'Aplikasi Rekap Pulsa','Aplikasi yang membantu pedagang pulsa',16,'2014-07-17 20:40:02',NULL,'Ongoing',3);
/*!40000 ALTER TABLE `t_job_sheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_job_sheet_application`
--

DROP TABLE IF EXISTS `t_job_sheet_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_job_sheet_application` (
  `id_job_sheet_application` int(11) NOT NULL AUTO_INCREMENT,
  `id_job_sheet` int(11) DEFAULT NULL,
  `id_student` int(11) DEFAULT NULL,
  `application_file` varchar(150) DEFAULT NULL,
  `waktu_daftar` datetime DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_job_sheet_application`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_job_sheet_application`
--

LOCK TABLES `t_job_sheet_application` WRITE;
/*!40000 ALTER TABLE `t_job_sheet_application` DISABLE KEYS */;
INSERT INTO `t_job_sheet_application` (`id_job_sheet_application`, `id_job_sheet`, `id_student`, `application_file`, `waktu_daftar`, `status`, `comment`) VALUES (7,24,7,'files/student/7/istilah.pdf','2014-07-06 13:45:51','1',' Berani Kerja Cepet'),(8,25,10,'files/student/10/8-babiii.pdf','2014-07-06 17:06:04','1',' Pengajuan Magang Ahmad Paudji'),(10,38,11,'files/student/11/Lamaran_Kerja.pdf','2014-07-13 16:16:27','1',' Lamaran kerja'),(11,36,8,'files/student/8/bab-3-diagram-aktivitas1.pdf','2014-07-13 16:38:26','1',' Lamar'),(12,40,12,'files/student/12/Lamaran_Kerja.pdf','2014-07-14 05:06:22','1','Lamaran magang atas nama Fahmi Khaerul'),(13,39,13,'files/student/13/bab-3-diagram-aktivitas.pdf','2014-07-14 09:48:22','1',' '),(14,41,14,'files/student/14/Lamaran_Kerja.pdf','2014-07-14 11:15:02','1','Lamaran Magang'),(15,42,15,'files/student/15/Lamaran_Kerja.pdf','2014-07-17 21:14:24','1',' Lamaran magang');
/*!40000 ALTER TABLE `t_job_sheet_application` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`ozantcom`@`localhost`*/ /*!50003 trigger tri_notif_company_pelamaran_jobsheet
after insert on t_job_sheet_application
for each row 
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select tu.id_user from t_job_sheet tjs join t_perusahaan tp on (tp.id_perusahaan = tjs.id_perusahaan) join t_user tu on (tu.id_user = tp.id_user) where tjs.id_job_sheet = new.id_job_sheet), 
concat('Pelamaran masuk untuk job sheet ', (select nama_job_sheet from t_job_sheet where id_job_sheet = new.id_job_sheet)), 
concat(concat('Pelamaran masuk untuk job sheet ', (select nama_job_sheet from t_job_sheet where id_job_sheet = new.id_job_sheet)), concat(' dari student bernama ', (select nama from t_student where id_student = new.id_student))), 
current_timestamp, 
'0') */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`ozantcom`@`localhost`*/ /*!50003 trigger tri_notif_student_lamaran_job_sheet_diterima
before update on t_job_sheet_application
for each row 
begin
if (new.status = '1') then
set new.status = '1';
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select id_user from t_student where id_student = new.id_student), 
'Status lamaran ', 
concat(concat('Status untuk lamaran ', (select nama_job_sheet from t_job_sheet where id_job_sheet = new.id_job_sheet)), concat(' dari Anda telah diterima ', ' ')), 
current_timestamp, 
'0');
elseif (new.status = '2') then
set new.status = '2';
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select id_user from t_student where id_student = new.id_student), 
'Status lamaran ', 
concat(concat('Status untuk lamaran ', (select nama_job_sheet from t_job_sheet where id_job_sheet = new.id_job_sheet)), concat(' telah ditolak ', ' ')), 
current_timestamp, 
'0');
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `t_jurusan`
--

DROP TABLE IF EXISTS `t_jurusan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_jurusan` (
  `id_jurusan` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_jurusan`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_jurusan`
--

LOCK TABLES `t_jurusan` WRITE;
/*!40000 ALTER TABLE `t_jurusan` DISABLE KEYS */;
INSERT INTO `t_jurusan` (`id_jurusan`, `nama`) VALUES (17,'Psikologi'),(16,'Teknik Informatika'),(18,'Manajemen Informatika'),(19,'Akuntansi'),(20,'Desain Komunikasi Visual'),(21,'Planologi'),(22,'Ekonomi'),(23,'Farmasi'),(24,'Bahasa dan Sastra'),(25,'Komunikasi'),(26,'Hukum'),(27,'MIPA');
/*!40000 ALTER TABLE `t_jurusan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_kota`
--

DROP TABLE IF EXISTS `t_kota`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_kota` (
  `id_kota` int(11) NOT NULL AUTO_INCREMENT,
  `id_provinsi` int(11) NOT NULL,
  `nama` varchar(25) NOT NULL,
  PRIMARY KEY (`id_kota`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_kota`
--

LOCK TABLES `t_kota` WRITE;
/*!40000 ALTER TABLE `t_kota` DISABLE KEYS */;
INSERT INTO `t_kota` (`id_kota`, `id_provinsi`, `nama`) VALUES (1,1,'Bandung'),(4,1,'Bogor'),(5,1,'Cimahi'),(6,1,'Jakarta'),(7,1,'Bekasi'),(8,1,'Sukabumi'),(9,1,'Majalengka'),(10,1,'Tasikmalaya'),(11,1,'Sumedang'),(12,1,'Banjar'),(13,1,'Cirebon'),(14,1,'Depok');
/*!40000 ALTER TABLE `t_kota` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_message`
--

DROP TABLE IF EXISTS `t_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_message` (
  `id_message` int(11) NOT NULL AUTO_INCREMENT,
  `id_user_pengirim` int(11) DEFAULT NULL,
  `id_user_penerima` int(11) DEFAULT NULL,
  `head` varchar(100) DEFAULT NULL,
  `body` text,
  `url` varchar(100) DEFAULT NULL,
  `tanggal` datetime DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  PRIMARY KEY (`id_message`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_message`
--

LOCK TABLES `t_message` WRITE;
/*!40000 ALTER TABLE `t_message` DISABLE KEYS */;
INSERT INTO `t_message` (`id_message`, `id_user_pengirim`, `id_user_penerima`, `head`, `body`, `url`, `tanggal`, `status`) VALUES (32,37,39,NULL,'Selamat sore',NULL,NULL,'1'),(33,39,37,NULL,'Selamat sore pak/bu ..',NULL,'2014-07-13 16:23:42','0'),(34,37,39,NULL,'Bagaimana pekerjaannya ? ada kesulitan?',NULL,NULL,'1'),(35,39,37,NULL,'sejauh ini belum ada pak/bu. mungkin joblist tentang analisis kebutuhan akan saya upload 2 hari lagi.',NULL,'2014-07-13 16:48:20','0'),(36,37,39,NULL,'Bagaimana pekerjaannya ? ada kesulitan?',NULL,NULL,'1'),(37,37,39,NULL,'baiklah kalau begitu, saya akan tunggu pekerjaan anda. lebih cepat lebih baik agar saya bisa memeriksa hasil pekerjaan anda.',NULL,NULL,'1'),(38,37,39,NULL,'untuk joblist analisis kebutuhan sudah saya upload pak, mohon untuk dicek. terima kasih ..',NULL,NULL,'1'),(39,40,41,NULL,'Assalamuallaikum',NULL,NULL,'1'),(40,41,40,NULL,'walaikumsalam pak/bu',NULL,'2014-07-14 05:42:16','0'),(41,37,39,NULL,'silahkan dikerjakan secepatnya',NULL,'2014-07-14 10:05:18','1'),(42,37,39,NULL,'secepatnya',NULL,'2014-07-14 10:05:56','1'),(43,39,37,NULL,'baik pak..',NULL,'2014-07-14 10:12:25','0'),(44,25,35,NULL,'mau tanya ??',NULL,'2014-07-14 10:24:28','0'),(45,35,25,NULL,'apa',NULL,'2014-07-14 10:26:07','1');
/*!40000 ALTER TABLE `t_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_notification`
--

DROP TABLE IF EXISTS `t_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_notification` (
  `id_notification` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `head` varchar(100) DEFAULT NULL,
  `body` text,
  `url` varchar(100) DEFAULT NULL,
  `tanggal` datetime DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  PRIMARY KEY (`id_notification`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_notification`
--

LOCK TABLES `t_notification` WRITE;
/*!40000 ALTER TABLE `t_notification` DISABLE KEYS */;
INSERT INTO `t_notification` (`id_notification`, `id_user`, `head`, `body`, `url`, `tanggal`, `status`) VALUES (24,25,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari perusahaan ',NULL,'2014-07-13 17:38:04','1'),(12,25,'Status lamaran ','Status untuk lamaran Kepegawaian dari Anda telah diterima  ',NULL,'2014-07-13 16:38:49','1'),(11,36,'Pelamaran masuk untuk job sheet Kepegawaian','Pelamaran masuk untuk job sheet Kepegawaian dari student bernama Handoyo',NULL,'2014-07-13 16:38:26','0'),(9,37,'Pelamaran masuk untuk job sheet Pembangunan Web Site','Pelamaran masuk untuk job sheet Pembangunan Web Site dari student bernama Wupi Ocktavia Kharismawati',NULL,'2014-07-13 16:16:27','0'),(10,39,'Status lamaran ','Status untuk lamaran Pembangunan Web Site dari Anda telah diterima  ',NULL,'2014-07-13 16:20:16','1'),(13,36,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari student bernama Handoyo',NULL,'2014-07-13 16:43:34','0'),(14,25,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari perusahaan ',NULL,'2014-07-13 16:44:47','1'),(16,36,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari student bernama Handoyo',NULL,'2014-07-13 16:54:47','0'),(17,36,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari student bernama Handoyo',NULL,'2014-07-13 16:57:18','0'),(18,36,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari student bernama Handoyo',NULL,'2014-07-13 16:58:32','0'),(19,37,'Upload file dari job list Analisis Kebutuhan','Upload file dari job sheet Pembangunan Web Site, job list Analisis Kebutuhan dari student bernama Wupi Ocktavia Kharismawati',NULL,'2014-07-13 17:05:27','0'),(20,NULL,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari perusahaan ',NULL,'2014-07-13 17:05:53','0'),(21,37,'Komentar baru dari job list Analisis Kebutuhan','Komentar baru dari job list Analisis Kebutuhan dari student bernama Wupi Ocktavia Kharismawati',NULL,'2014-07-13 17:07:04','0'),(22,NULL,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari perusahaan ',NULL,'2014-07-13 17:19:05','0'),(23,NULL,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari perusahaan ',NULL,'2014-07-13 17:23:23','0'),(25,39,'Komentar baru dari job list Analisis Kebutuhan','Komentar baru dari job list Analisis Kebutuhan dari perusahaan ',NULL,'2014-07-13 17:48:31','1'),(26,25,'Komentar baru dari job list Analisis Data Kepegawaian','Komentar baru dari job list Analisis Data Kepegawaian dari perusahaan ',NULL,'2014-07-13 17:49:37','1'),(27,39,'Perubahan status job list ','Status untuk job list Analisis Kebutuhan telah selesai  ',NULL,'2014-07-13 19:45:51','1'),(28,NULL,'Perubahan status job list ','Status untuk job list Class Diagram telah selesai  ',NULL,'2014-07-13 19:46:32','0'),(29,39,'Perubahan status job list ','Status untuk job list Analisis Kebutuhan telah selesai  ',NULL,'2014-07-13 19:46:32','1'),(30,NULL,'Perubahan status job list ','Status untuk job list Use Case telah selesai  ',NULL,'2014-07-13 19:46:32','0'),(31,NULL,'Perubahan status job list ','Status untuk job list Analisis Sistem yang Berjalan telah selesai  ',NULL,'2014-07-14 04:45:53','0'),(32,40,'Pelamaran masuk untuk job sheet Aplikasi Pengelolaan Gaji','Pelamaran masuk untuk job sheet Aplikasi Pengelolaan Gaji dari student bernama Fahmi Khaerul',NULL,'2014-07-14 05:06:22','0'),(33,41,'Status lamaran ','Status untuk lamaran Aplikasi Pengelolaan Gaji dari Anda telah diterima  ',NULL,'2014-07-14 05:20:41','1'),(34,41,'Komentar baru dari job list Analisis Sistem yang Berjalan','Komentar baru dari job list Analisis Sistem yang Berjalan dari perusahaan ',NULL,'2014-07-14 05:25:05','1'),(35,40,'Komentar baru dari job list Analisis Sistem yang Berjalan','Komentar baru dari job list Analisis Sistem yang Berjalan dari student bernama Fahmi Khaerul',NULL,'2014-07-14 05:36:49','0'),(36,40,'Upload file dari job list Analisis Sistem yang Berjalan','Upload file dari job sheet Aplikasi Pengelolaan Gaji, job list Analisis Sistem yang Berjalan dari student bernama Fahmi Khaerul',NULL,'2014-07-14 05:47:02','0'),(37,37,'Pelamaran masuk untuk job sheet Pembanguan Aplikasi Zakat','Pelamaran masuk untuk job sheet Pembanguan Aplikasi Zakat dari student bernama Asas',NULL,'2014-07-14 09:48:22','0'),(38,42,'Status lamaran ','Status untuk lamaran Pembanguan Aplikasi Zakat dari Anda telah diterima  ',NULL,'2014-07-14 09:59:34','1'),(39,37,'Upload file dari job list Analisis Sistem yang Berjalan','Upload file dari job sheet Pembanguan Aplikasi Zakat, job list Analisis Sistem yang Berjalan dari student bernama Asas',NULL,'2014-07-14 10:08:27','0'),(40,42,'Perubahan status job list ','Status untuk job list Analisis Sistem yang Berjalan telah selesai  ',NULL,'2014-07-14 10:46:58','0'),(41,42,'Perubahan status job list ','Status untuk job list Analisis Sistem yang Berjalan telah selesai  ',NULL,'2014-07-14 10:48:27','0'),(42,44,'Pelamaran masuk untuk job sheet Aplikasi Pengelolaan Gaji','Pelamaran masuk untuk job sheet Aplikasi Pengelolaan Gaji dari student bernama Wupi Ocktavia K',NULL,'2014-07-14 11:15:02','0'),(43,43,'Status lamaran ','Status untuk lamaran Aplikasi Pengelolaan Gaji dari Anda telah diterima  ',NULL,'2014-07-14 11:19:05','0'),(44,43,'Komentar baru dari job list Analisis Sistem yang Berjalan','Komentar baru dari job list Analisis Sistem yang Berjalan dari perusahaan ',NULL,'2014-07-14 11:20:10','0'),(45,NULL,'Perubahan status job list ','Status untuk job list Analisis Sistem yang Berjalan telah selesai  ',NULL,'2014-07-14 13:46:20','0'),(46,37,'Pelamaran masuk untuk job sheet Aplikasi Rekap Pulsa','Pelamaran masuk untuk job sheet Aplikasi Rekap Pulsa dari student bernama Zahra Aurora Sora',NULL,'2014-07-17 21:14:24','0'),(47,45,'Status lamaran ','Status untuk lamaran Aplikasi Rekap Pulsa dari Anda telah diterima  ',NULL,'2014-07-17 21:21:37','0');
/*!40000 ALTER TABLE `t_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_penilaian`
--

DROP TABLE IF EXISTS `t_penilaian`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_penilaian` (
  `id_penilaian` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `disiplin` int(50) NOT NULL,
  `tanggap` int(11) NOT NULL,
  `cermat` int(11) NOT NULL,
  `rajin` int(11) NOT NULL,
  `komunikasi` int(11) NOT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_penilaian`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_penilaian`
--

LOCK TABLES `t_penilaian` WRITE;
/*!40000 ALTER TABLE `t_penilaian` DISABLE KEYS */;
INSERT INTO `t_penilaian` (`id_penilaian`, `id_user`, `disiplin`, `tanggap`, `cermat`, `rajin`, `komunikasi`, `keterangan`) VALUES (8,39,60,40,100,60,40,NULL);
/*!40000 ALTER TABLE `t_penilaian` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_perusahaan`
--

DROP TABLE IF EXISTS `t_perusahaan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_perusahaan` (
  `id_perusahaan` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `id_kota` int(11) DEFAULT NULL,
  `kode_pos` varchar(6) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `id_user` int(11) NOT NULL,
  `website` varchar(50) DEFAULT NULL,
  `about` text,
  PRIMARY KEY (`id_perusahaan`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_perusahaan`
--

LOCK TABLES `t_perusahaan` WRITE;
/*!40000 ALTER TABLE `t_perusahaan` DISABLE KEYS */;
INSERT INTO `t_perusahaan` (`id_perusahaan`, `nama`, `alamat`, `id_kota`, `kode_pos`, `telepon`, `id_user`, `website`, `about`) VALUES (27,'Smart Inovation','Dipatiukur No. 123',1,'40132','0226654024',44,'smartinovation.com','Smart Inovation adalah perusahaan yang bergerak dibidang teknologi.'),(26,'Technologi Profesional','JLN.BUKIT DAGO SELATAN NO 123',1,'40135','085723456123',40,'technopro.com','Technologi Profesional adalah perusahaan yang bergerak dibidang IT. Techno Pro berdiri sejak tahun 2013. Techno Pro banyak menangani permintaan klien dalam bentuk aplikasi dan web site.'),(16,'Ozansoft','Jalan Titiran',1,'54112','085752225126',26,'ozan-soft.com','Perusahaan ini adalah perusahaan yang bergerak dibidang IT khususnya bidang software developer untuk \nsoftware berbasis web, mobile, dan desktop.'),(17,'Pertamina','Jalan Japati',1,'54112','0225206654',27,'pertamina.com','As a state-owned company To carry out integrated business core in oil, gas, renewable and new energy based on strong commercial principles both inside and outside the country, Pertamina strives to provide the best and a real contribution to the welfare of the nation in utilizing every potential of Indonesia.'),(18,'Telkom Indonesia','Jl. Japati',1,'54112','022516256',28,'telkom.co.id','Telkom Group is the only state-owned telecommunications enterprise as well as telecommunications and network service providers in Indonesia.'),(19,'NET.(mediatama)','jakarta jakarta',1,'12121','0215555555555',32,'netmedia.co.id','Net Mediatama Indonesia\nNET. adalah bagian dari kelompok usaha INDIKA GROUP. Meskipun bergerak di bidang usaha Energi & Sumberdaya di bawah bendera Indika Energy Tbk. (www.indikaenergy.com), berdirinya INDIKA dimulai dari sebuah visi untuk membangun usaha di bidang Media Hiburan dan Teknologi Informasi. Nama INDIKA sendiri merupakan singkatan dari Industri Multimedia dan Informatika. Saat ini, melalui PT. Indika Multimedia, INDIKA GROUP bergerak di bidang usaha Event Organizer, Promotor, Broadcast Equipment, Production House dan Radio'),(20,'telkomsel indonesia','jakarta jakarta',1,'12121','021555553333',33,'telkomsel.com','Vision\nMenjadi penyedia layanan dan solusi mobile digital lifestyle kelas dunia yang terpercaya. \n\nMission \nMemberikan layanan dan solusi mobile digital yang melebihi ekspektasi pelanggan, memberikan nilai tambah kepada para stakeholders, dan mendukung pertumbuhan ekonomi bangsa.'),(21,'Kimia Farma','jakarta jakarta',1,'12121','0219999996969',34,'kimiafarma.co.id','SEKILAS KIMIA FARMA\n \nKimia Farma adalah perusahaan industri farmasi pertama di Indonesia yang didirikan oleh Pemerintah Hindia Belanda tahun 1817. Nama perusahaan ini pada awalnya adalah NV Chemicalien Handle Rathkamp & Co. Berdasarkan kebijaksanaan nasionalisasi atas eks perusahaan Belanda di masa awal kemerdekaan, pada tahun 1958, Pemerintah Republik Indonesia melakukan peleburan sejumlah perusahaan farmasi menjadi PNF (Perusahaan Negara Farmasi) Bhinneka Kimia Farma. Kemudian pada tanggal 16 Agustus 1971, bentuk badan hukum PNF diubah menjadi Perseroan Terbatas, sehingga nama perusahaan berubah menjadi PT Kimia Farma (Persero).\nPada tanggal 4 Juli 2001, PT Kimia Farma (Persero) kembali mengubah statusnya menjadi perusahaan publik, PT Kimia Farma (Persero) Tbk, dalam penulisan berikutnya disebut Perseroan. Bersamaan dengan perubahan tersebut, Perseroan telah dicatatkan pada Bursa Efek Jakarta dan Bursa Efek Surabaya (sekarang kedua bursa telah merger dan kini bernama Bursa Efek Indonesia). Berbekal pengalaman selama puluhan tahun, Perseroan telah berkembang menjadi perusahaan dengan pelayanan kesehatan terintegrasi di Indonesia. Perseroan kian diperhitungkan kiprahnya dalam pengembangan dan pembangunan bangsa, khususnya pembangunan kesehatan masyarakat Indonesia.'),(22,'PT. PLN PERSERO','jalan cilegon serang',1,'42161','0254223123',35,'pln.co.id','Perusahaan listrik negara'),(23,'Baju Bekas','Jl. Taman No.22',1,'40132','02229122121',36,NULL,NULL),(24,'Smart T','JL. BUKIT DAGO',1,'40135','0227541211',37,'','Smart T adalah perusahaan yang berdiri pada tahun 2014. Perusahaan ini bergerak dibidang Teknologi.'),(25,'Rumah Bekas','Jl. Kopo No.23',1,'40132','022293291212',38,NULL,NULL);
/*!40000 ALTER TABLE `t_perusahaan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_provinsi`
--

DROP TABLE IF EXISTS `t_provinsi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_provinsi` (
  `id_provinsi` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id_provinsi`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_provinsi`
--

LOCK TABLES `t_provinsi` WRITE;
/*!40000 ALTER TABLE `t_provinsi` DISABLE KEYS */;
INSERT INTO `t_provinsi` (`id_provinsi`, `nama`) VALUES (1,'Jawa Barat'),(2,'Jawa Timur'),(3,'Jawa Tengah'),(4,'Aceh'),(5,'Bali'),(6,'Banten'),(7,'Bengkulu'),(8,'Jakarta'),(9,'Gorontalo'),(10,'Kalimantan Utara'),(11,'Kalimantan Barat'),(12,'Kalimantan Selatan'),(13,'Kalimantan Timur'),(14,'Kalimantan Tengah'),(15,'Yogyakarta'),(16,'Lampung'),(17,'Maluku'),(18,'Maluku Utara'),(19,'Sulawesi Tenggara'),(20,'Sulawesi Barat'),(21,'Sulawesi Tengah'),(22,'Sulawesi Selatan'),(23,'Sumatera Utara'),(24,'Sumatera Barat'),(25,'Sumatera Selatan');
/*!40000 ALTER TABLE `t_provinsi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_student`
--

DROP TABLE IF EXISTS `t_student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_student` (
  `id_student` int(11) NOT NULL AUTO_INCREMENT,
  `id_universitas` int(11) DEFAULT NULL,
  `nim` varchar(12) DEFAULT NULL,
  `id_jurusan` int(25) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` text,
  `id_kota` int(11) DEFAULT NULL,
  `kode_pos` varchar(6) DEFAULT NULL,
  `telepon` varchar(13) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_student`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_student`
--

LOCK TABLES `t_student` WRITE;
/*!40000 ALTER TABLE `t_student` DISABLE KEYS */;
INSERT INTO `t_student` (`id_student`, `id_universitas`, `nim`, `id_jurusan`, `nama`, `alamat`, `id_kota`, `kode_pos`, `telepon`, `email`, `id_user`) VALUES (7,1,'10111099',16,'Ismail Zakky','asdasdasdsad',1,'14045','02154201145','ismailzakky2@yahoo.com',21),(8,1,'10111078',16,'Handoyo','Sekeloa',1,'42123','087871942562','dyo.9913@gmail.com',25),(9,1,'10113801',17,'Muhammad Maududi Z.','Jl. Cisitu Lama 9 no. 38',1,'22222','085221572105','dudy_d2@yahoo.co.id',29),(10,1,'10111104',16,'Ahmad Paudji','Jl.Titiran',1,'76112','085752225126','ahmadpaudji@gmail.com',30),(11,1,'10111068',16,'Wupi Ocktavia Kharismawati','Kp. Tangkil RT 06 RW 07 NO 179',1,'40522','085721537326','wupiocktavia@ymail.com',39),(12,1,'10111408',16,'Fahmi Khaerul','Jln. Radio no 234 Sukabumi',8,'43122','085624661661','fahmikhaerul@gmail.com',41),(13,1,'10112111',16,'Asas','Alamat anda',1,'42111','1212121','asa@gmail.com',42),(14,1,'10111068',16,'Wupi Ocktavia K','Kp. Tangkil RT 06 RW 07 Cigugur Tengah',5,'40522','085721537326','wupiocktavia@yahoo.com',43),(15,2,'10111068',16,'Zahra Aurora Sora','Kp. Tangkil',5,'40522','0226645024','zahra@gmail.com',45);
/*!40000 ALTER TABLE `t_student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_student_job_list`
--

DROP TABLE IF EXISTS `t_student_job_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_student_job_list` (
  `id_student_job_list` int(11) NOT NULL AUTO_INCREMENT,
  `id_job_list` int(11) DEFAULT NULL,
  `id_student` int(11) DEFAULT NULL,
  `file_user` varchar(100) DEFAULT NULL,
  `waktu_upload_file` datetime DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_student_job_list`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_student_job_list`
--

LOCK TABLES `t_student_job_list` WRITE;
/*!40000 ALTER TABLE `t_student_job_list` DISABLE KEYS */;
INSERT INTO `t_student_job_list` (`id_student_job_list`, `id_job_list`, `id_student`, `file_user`, `waktu_upload_file`, `keterangan`) VALUES (4,35,7,NULL,NULL,NULL),(5,36,7,NULL,NULL,NULL),(6,37,7,NULL,NULL,NULL),(7,38,7,NULL,NULL,NULL),(8,39,7,NULL,NULL,NULL),(9,52,11,'files/student/11/Analisis_Model_Data.pdf','2014-07-13 17:05:27',NULL),(10,57,12,'files/student/12/DFD_PROTOTYPE_MALL.pdf','2014-07-14 05:48:04',NULL),(11,55,13,'files/student/13/bab-3-diagram-aktivitas1.pdf','2014-07-14 10:08:27',NULL);
/*!40000 ALTER TABLE `t_student_job_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`ozantcom`@`localhost`*/ /*!50003 trigger tri_notif_company_upload_student_job_list
after insert on t_student_job_list
for each row 
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select tu.id_user from t_job_list tjl join t_job_sheet tjs on (tjl.id_job_sheet = tjs.id_job_sheet) join t_perusahaan tp on (tp.id_perusahaan = tjs.id_perusahaan) join t_user tu on (tu.id_user = tp.id_user) where tjl.id_job_list = new.id_job_list), 
concat('Upload file dari job list ', (select head from t_job_list where id_job_list = new.id_job_list)), 
concat(concat(concat('Upload file dari job sheet ', (select tjs.nama_job_sheet from t_job_list tjl join t_job_sheet tjs on (tjs.id_job_sheet = tjl.id_job_sheet) where tjl.id_job_list = new.id_job_list)), concat(', job list ', (select head from t_job_list where id_job_list = new.id_job_list))), concat(' dari student bernama ', (select nama from t_student where id_student = new.id_student))), 
current_timestamp, 
'0') */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `t_student_job_sheet`
--

DROP TABLE IF EXISTS `t_student_job_sheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_student_job_sheet` (
  `id_student_job_sheet` int(11) NOT NULL AUTO_INCREMENT,
  `id_job_sheet` int(11) DEFAULT NULL,
  `id_student` int(11) DEFAULT NULL,
  `waktu_start` datetime DEFAULT NULL,
  `waktu_akhir` datetime DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_student_job_sheet`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_student_job_sheet`
--

LOCK TABLES `t_student_job_sheet` WRITE;
/*!40000 ALTER TABLE `t_student_job_sheet` DISABLE KEYS */;
INSERT INTO `t_student_job_sheet` (`id_student_job_sheet`, `id_job_sheet`, `id_student`, `waktu_start`, `waktu_akhir`, `status`, `keterangan`) VALUES (10,24,7,'2014-07-06 13:47:59',NULL,'1',NULL),(11,25,10,'2014-07-06 17:16:09',NULL,'1',NULL),(12,38,11,'2014-07-13 16:20:16',NULL,'1',NULL),(13,36,8,'2014-07-13 16:38:49',NULL,'1',NULL),(14,40,12,'2014-07-14 05:20:41','2014-10-14 05:20:41','1',NULL),(15,39,13,'2014-07-14 09:59:34','2014-09-14 09:59:34','1',NULL),(16,41,14,'2014-07-14 11:19:05','2014-09-14 11:19:05','1',NULL),(17,42,15,'2014-07-17 21:21:37','2014-10-17 21:21:37','1',NULL);
/*!40000 ALTER TABLE `t_student_job_sheet` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`ozantcom`@`localhost`*/ /*!50003 trigger tri_notif_student_jobsheet
before insert on t_student_job_sheet
for each row
begin 
set new.waktu_akhir = new.waktu_start + interval (select durasi from t_job_sheet where id_job_sheet = new.id_job_sheet) month;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`ozantcom`@`localhost`*/ /*!50003 trigger tri_notif_student_status_job_sheet
before update on t_student_job_sheet
for each row 
begin
if (new.status = '0') then
set new.status = '0';
insert into t_notification(id_user, head, body, tanggal, status)
values (
(select id_user from t_student where id_student = new.id_student), 
concat('Status job sheet ', (select nama_job_sheet from t_job_sheet where id_job_sheet = new.id_job_sheet)), 
concat(concat('Status untuk job sheet ', (select nama_job_sheet from t_job_sheet where id_job_sheet = new.id_job_sheet)), concat(' telah ditutup oleh perusahaan ', ' ')), 
current_timestamp, 
'0');
end if;
end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `t_universitas`
--

DROP TABLE IF EXISTS `t_universitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_universitas` (
  `id_universitas` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` text,
  `id_kota` int(11) DEFAULT NULL,
  `kode_pos` varchar(6) DEFAULT NULL,
  `telepon` varchar(13) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_universitas`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_universitas`
--

LOCK TABLES `t_universitas` WRITE;
/*!40000 ALTER TABLE `t_universitas` DISABLE KEYS */;
INSERT INTO `t_universitas` (`id_universitas`, `nama`, `alamat`, `id_kota`, `kode_pos`, `telepon`, `website`) VALUES (1,'Universitas Komputer Indonesia','Jl. Dipati Ukur No 112\n',1,'40132','0222504119','www.unikom.ac.id'),(2,'Universitas Padjajaran','Jl. Dipati Ukur No 35',1,'40132','0222503271','www.unpad.ac.id'),(3,'Universitas Pendidikan Indonesia','Jl. Dr. Setiabudhi No. 229',1,'40154','0222013161-64','www.upi.edu'),(4,'Institut Teknologi Bandung','Jl. Tamansari 64 Bandung',1,'40116','0222500935','www.itb.ac.id'),(6,'Politeknik Negeri Bandung','Jl. Gegerkalong Hilir Ds. Ciwaruga',1,'40012','0222013789','www.polban.ac.id'),(7,'UIN Sunan Gunung Djati Bandung','Jl. AH Nasution No. 105',1,'10614','0227800525','www.uinsgd.ac.id'),(8,'Universitas Islam Bandung','Jl. Tamansari No.1, 20, 22, 24, 26',1,'40116','0224205546','www.unisba.ac.id'),(9,'Universitas Jenderal Achmad Yani','Jl. Terusan Jenderal Sudirman PO BOX 148',1,'40285','0226652069','www.unjani.ac.id');
/*!40000 ALTER TABLE `t_universitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_user`
--

DROP TABLE IF EXISTS `t_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `foto_user` varchar(150) DEFAULT NULL,
  `status_user` enum('COMPANY','STUDENT','ADMIN') DEFAULT NULL,
  `tanggal_masuk` datetime DEFAULT NULL,
  `block` tinyint(4) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_user`
--

LOCK TABLES `t_user` WRITE;
/*!40000 ALTER TABLE `t_user` DISABLE KEYS */;
INSERT INTO `t_user` (`id_user`, `email`, `password`, `foto_user`, `status_user`, `tanggal_masuk`, `block`, `last_login`) VALUES (20,'ismailzakky@yahoo.com','24de4b0074f620f824a8f24de7747eb8','388748.png','COMPANY','2014-07-06 13:15:29',0,NULL),(21,'ismailzakky2@yahoo.com','24de4b0074f620f824a8f24de7747eb8',NULL,'STUDENT','2014-07-06 13:41:28',0,'2014-07-06 13:41:42'),(22,'zakky@yahoo.com','24de4b0074f620f824a8f24de7747eb8',NULL,'COMPANY','2014-07-06 13:50:22',0,NULL),(23,'zakky3@yahoo.com','24de4b0074f620f824a8f24de7747eb8',NULL,'COMPANY','2014-07-06 13:57:16',0,NULL),(24,'test12@yahoo.com','24de4b0074f620f824a8f24de7747eb8',NULL,'COMPANY','2014-07-06 13:59:39',0,NULL),(25,'dyo.9913@gmail.com','57ba172a6be125cca2f449826f9980ca','images/student/8/bb.jpg','STUDENT','2014-07-06 14:11:37',0,'2014-07-14 11:38:44'),(26,'ahmadpaudji@ozan-soft.com','01fe468bef29d2537b2571a8cebf9c30','images.jpg','COMPANY','2014-07-06 14:47:18',0,NULL),(27,'pertamina@gmail.com','6b2244ecf5881e4aa6d4235d16be7b48','pertamina.jpg','COMPANY','2014-07-06 14:55:09',0,NULL),(28,'telkom@gmail.com','6b2244ecf5881e4aa6d4235d16be7b48','telkom.png','COMPANY','2014-07-06 14:56:46',0,NULL),(29,'dudy_d2@yahoo.co.id','7c467362ba62638a448bd91cc48b5c89',NULL,'STUDENT','2014-07-06 15:03:53',0,'2014-07-06 17:17:53'),(30,'ahmadpaudji@gmail.com','01fe468bef29d2537b2571a8cebf9c30','images/student/10/ozzy2.jpg','STUDENT','2014-07-06 15:29:46',0,'2014-07-17 23:19:40'),(31,'admin@yahoo.com','cc03e747a6afbbcbf8be7668acfebee5','null','ADMIN','0000-00-00 00:00:00',0,'2014-07-14 10:36:16'),(32,'net@yahoo.co.id','c070f19a3113a179a114656cc68d0af5',NULL,'COMPANY','2014-07-06 16:15:15',0,NULL),(33,'telkomsel@yahoo.co.id','51b0c69926535e5289cddf6f27c64631',NULL,'COMPANY','2014-07-06 16:29:35',0,NULL),(34,'kimiafarma@yahoo.co.id','ff0ae55331bcfb7adc7de5c2a7a02a96',NULL,'COMPANY','2014-07-06 16:47:02',0,NULL),(35,'pln@gmail.com','59dc2c3921372dd78bc538c65a4b8b70','download.jpg','COMPANY','2014-07-13 15:00:41',0,NULL),(36,'bajubekas@bajubekas.com','ff5d7e90747a9ec9cc303e0578489651',NULL,'COMPANY','2014-07-13 15:06:46',0,NULL),(37,'smarttech@gmail.com','9da3222fec8f07278965bd397a9e5415','logo.png','COMPANY','2014-07-13 15:13:29',0,NULL),(38,'rumahbekas@rumahbekas.com','52b29189c223c7d7b60f9162240f4455',NULL,'COMPANY','2014-07-13 15:20:51',0,NULL),(39,'wupiocktavia@ymail.com','5222e4e61417894ab8a04ec3b868360a','images/student/11/upi1.jpg','STUDENT','2014-07-13 15:54:55',0,'2014-07-17 21:04:21'),(40,'technopro@gmail.com','d9692aa742478e7aee24b2a28c26d878','logo_(1).png','COMPANY','2014-07-14 04:20:10',0,NULL),(41,'fahmikhaerul@gmail.com','2aadd97a0466302b1ded7f88e94a5f32','images/student/12/fahmi.jpg','STUDENT','2014-07-14 04:58:35',0,'2014-07-14 05:01:45'),(42,'asa@gmail.com','57ba172a6be125cca2f449826f9980ca',NULL,'STUDENT','2014-07-14 09:46:04',0,'2014-07-14 11:13:29'),(43,'wupiocktavia@yahoo.com','5222e4e61417894ab8a04ec3b868360a','images/student/14/C360_2013-08-31-09-25-11.jpg','STUDENT','2014-07-14 11:02:48',0,'2014-07-14 13:07:22'),(44,'smartinovation@yahoo.com','e086c812156410e97bc5cc284c4d1ec8','logo2.jpg','COMPANY','2014-07-14 11:05:28',0,NULL),(45,'zahra@gmail.com','1735bd8850ff9c0ba7955967d0371762',NULL,'STUDENT','2014-07-17 21:07:37',0,'2014-07-17 21:30:33');
/*!40000 ALTER TABLE `t_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-18 11:29:34
