<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Block extends CI_Controller {

	public function index()
	{
		
	}

	public function user(){

	}

	public function company(){

	}

}

/* End of file block.php */
/* Location: ./application/controllers/admin/block.php */