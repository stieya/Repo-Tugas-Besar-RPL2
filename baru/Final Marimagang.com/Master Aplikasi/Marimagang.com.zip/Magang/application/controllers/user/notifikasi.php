<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Notifikasi extends User_Controller {

	public function index()
	{
		
	}

}

/* End of file notifikasi.php */
/* Location: ./application/controllers/user/notifikasi.php */